package controller;

import helper.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.User;
import model.registers;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the Login screen
 */
public class loginController implements Initializable {
    public TextField loginUsernameText;
    public TextField loginPasswordText;
    public Button loginButton;
    public Button loginExitButton;
    public Label loginUser;
    public Label loginPass;
    public Label invalidNameOrPassword;
    public Label loginZoneIDLbl;
    public Label zoneIDLblForTranslation;
    public Label customerSchedulingApplicationLbl;
    ResultSet rs;
    @Override
    /**
     * This is an initialize method and it is basically a main method but for the Login screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connection loginConnection = JDBC.getConnection();
        loginZoneIDLbl.setText(ZoneId.systemDefault().toString());
        ResourceBundle rb = ResourceBundle.getBundle("languages/Nat", Locale.getDefault());
        if (Locale.getDefault().getLanguage().equals("fr")) {
            customerSchedulingApplicationLbl.setText(rb.getString("CustomerSchedulingApplication"));
            loginUser.setText(rb.getString("Username"));
            loginPass.setText(rb.getString("Password"));
            zoneIDLblForTranslation.setText(rb.getString("ZoneID"));
            loginButton.setText(rb.getString("Login"));
            loginExitButton.setText(rb.getString("Exit"));
        }
    }


    /**
     * This method allows one to login to the application and checks if the username and password are a valid match, and tracks the login attempts in a text file.
     *
     * @param actionEvent the ActionEvent
     * @throws SQLException an SQLException
     * @throws IOException  an IOException
     */
    public void onLoginButton(ActionEvent actionEvent) throws SQLException, IOException {
        if (loginUsernameText.getText().isBlank() && loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("en")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a value for the username and password");
            alert.showAndWait();
        } else if (loginUsernameText.getText().isBlank() && Locale.getDefault().getLanguage().equals("en")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a value for the username");
            alert.showAndWait();
        } else if (loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("en")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please enter a value for the password");
            alert.showAndWait();
        } else if (loginUsernameText.getText().isBlank() && loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("fr")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Veuillez saisir une valeur pour le nom d'utilisateur et le mot de passe");
            alert.showAndWait();
        } else if (loginUsernameText.getText().isBlank() && Locale.getDefault().getLanguage().equals("fr")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Veuillez saisir une valeur pour le nom d'utilisateur");
            alert.showAndWait();
        } else if (loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("fr")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Veuillez saisir une valeur pour le mot de passe");
            alert.showAndWait();
        }

        Parent root;
        Scene scene;
        Stage stage;
        if (!loginUsernameText.getText().isBlank() && !loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("en")) {
            String username = loginUsernameText.getText();
            String password = loginPasswordText.getText();
            rs = UserSQL.giveMeUserInformationForMatchingUsernameAndPassword(username, password);
            if (rs.next()) {
                try {
                    String filename = "login_activity.txt";
                    FileWriter fw = new FileWriter(filename, true); //the true will append the new data
                    fw.write("Username:" + username + "|" + "Password:" + password + "|" + " Successful Login Attempt At:  " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                    fw.close();
                } catch (IOException ioe) {
                    System.err.println("IOException: " + ioe.getMessage());
                }
                //Second Lambda expression greets the logged in user with an Information box
                String finalUsername = username;
                /**
                 * This Lambda expression is used to greets an individual by their username when they login
                 * @param Username the username
                 * @return Username the username
                 */
                greeterInterface greet = (Username) -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("You have succesfully logged in " + finalUsername);
                    boolean fifteenMins = timeManagement.isWithin15Mins();
                    if(fifteenMins == true){
                        registers.setIsWithinFifteenMinutes(true);
                    }
                    alert.showAndWait();
                    return Username;
                };
                greet.greet(username);
                System.out.println(greet);
                registers.setLoggedInUser(new User(rs.getInt("User_ID"), username, password));
                root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
                stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
            else {

                if (Locale.getDefault().getLanguage().equals("fr")) {
                    try {
                        String filename = "login_activity.txt";
                        FileWriter fw = new FileWriter(filename, true); //the true will append the new data
                        fw.write("Nom d'utilisateur:" + loginUsernameText.getText() + "|" + "Mot de passe:" + loginPasswordText.getText() + "|" + "Échec de la connexion à:  " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                        fw.close();
                    } catch (IOException ioe) {
                        System.err.println("IOException: " + ioe.getMessage());
                    }
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Entrée incorrecte!");
                    alert.showAndWait();
                    loginUsernameText.setText("");
                    loginPasswordText.setText("");
                    zoneIDLblForTranslation.setText("Identifiant de zone");
                    invalidNameOrPassword.setText("Nom d'utilisateur ou mot de passe invalide");

                } else if((Locale.getDefault().getLanguage().equals("en"))) {
                    try {
                        String filename = "login_activity.txt";
                        FileWriter fw = new FileWriter(filename, true); //the true will append the new data
                        fw.write("Username:" + loginUsernameText.getText() + "|" + "Password:" + loginPasswordText.getText() + "|" + " Failed Login Attempt At:  " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                        fw.close();
                    } catch (IOException ioe) {
                        System.err.println("IOException: " + ioe.getMessage());
                    }
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Incorrect input!");
                    alert.showAndWait();
                    loginUsernameText.setText("");
                    loginPasswordText.setText("");
                    zoneIDLblForTranslation.setText("Zone ID:");
                    invalidNameOrPassword.setText("Invalid Username Or Password");
                }
            }
        } else if (!loginUsernameText.getText().isBlank() && !loginPasswordText.getText().isBlank() && Locale.getDefault().getLanguage().equals("fr")) {
            String username = loginUsernameText.getText();
            String password = loginPasswordText.getText();
            rs = UserSQL.giveMeUserInformationForMatchingUsernameAndPassword(username, password);
            //Forward scroll rs set
            if (rs.next()) {
                try {
                    String filename = "login_activity.txt";
                    FileWriter fw = new FileWriter(filename, true); //the true will append the new data
                    fw.write("Nom d'utilisateur:" + username + "|" + "Mot de passe:" + password + "|" + " Tentative de connexion réussie à:  " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                    fw.close();
                } catch (IOException ioe) {
                    System.err.println("IOException: " + ioe.getMessage());
                }
                //Second Lambda expression greets the logged in user with an Information box
                String finalUsername1 = username;
                greeterInterface greet = (Username) -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setContentText("Vous vous êtes connecté avec succès " + finalUsername1);
                    boolean fifteenMins = timeManagement.isWithin15Minsfr();
                   if(fifteenMins == true){  registers.setIsWithinFifteenMinutes(true);}
                    alert.showAndWait();
                    return Username;
                };
                greet.greet(username);
                System.out.println(greet);
                registers.setLoggedInUser(new User(rs.getInt("User_ID"), username, password));
                root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
                stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }
        }
    }


    /**
     * This method allows one to close the application when pressed
     */
    public void onLoginExitButton() {
        Stage stage = (Stage) loginExitButton.getScene().getWindow();
        stage.close();
    }
}
