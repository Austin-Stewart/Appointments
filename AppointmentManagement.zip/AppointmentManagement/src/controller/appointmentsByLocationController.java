package controller;

import helper.AppointmentSQL;
import helper.timeManagement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.appointment;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the appointmentsByLocation screen
 */
public class appointmentsByLocationController implements Initializable {

    public Stage stage;
    public Scene scene;
    public Parent root;
    public TableView<appointment> locationReportAppointmentTableView;
    public TableColumn<? extends Object, ? extends Object> locationReportAppointmentIDCol;
    public TableColumn<? extends Object, ? extends Object> locationReportTitleCol;
    public TableColumn<? extends Object, ? extends Object> locationReportTypeCol;
    public TableColumn<? extends Object, ? extends Object> locationReportDescriptionCol;
    public TableColumn<? extends Object, ? extends Object> locationReportStartCol;
    public TableColumn<? extends Object, ? extends Object> locationReportEndCol;
    public TableColumn<? extends Object, ? extends Object> locationReportLocationColCol;
    public Label currentLoggedInUser;
    public ComboBox<String> SelectLocationForAppointmentsComboBox;

    @FXML
    /**
     * This method places all of the locations which can be picked into the SelectLocationForAppointmentsComboBox
     */
    private void setupLocationBox() {
        //Clears the list before loading it so that it doesn't get repeat customer entries
        SelectLocationForAppointmentsComboBox.setItems(registers.getAllLocations());
    }

    /**
     * This method places all of the appointments which occur at the selected location into the locationReportAppointmentTableView
     *
     * @throws SQLException an SQLException
     */
    public void onSelectLocationForReport() throws SQLException {
        ResultSet appointmentsByLocationResultSet = AppointmentSQL.giveMeAppointmentsByLocation(SelectLocationForAppointmentsComboBox);
        while (appointmentsByLocationResultSet.next()) {
            registers.getAllappointments().add(new appointment(appointmentsByLocationResultSet.getInt("Appointment_ID"), appointmentsByLocationResultSet.getString("Title"), appointmentsByLocationResultSet.getString("Description"), appointmentsByLocationResultSet.getString("Location"), appointmentsByLocationResultSet.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentsByLocationResultSet.getDate("Start").toLocalDate(), appointmentsByLocationResultSet.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentsByLocationResultSet.getDate("End").toLocalDate(), appointmentsByLocationResultSet.getTime("End").toLocalTime()), appointmentsByLocationResultSet.getInt("Customer_ID"), appointmentsByLocationResultSet.getInt("User_ID"), appointmentsByLocationResultSet.getInt("Contact_ID")));
            locationReportAppointmentTableView.setItems(registers.getAllAppointments());
        }

    }


    @Override
    /**
     * This is an initialize method and it is basically a main method but for the appointmentsByLocation report screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        currentLoggedInUser.setText(registers.getLoggedInUser().getUserName());
        setupLocationBox();
        locationReportAppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentID"));
        locationReportLocationColCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        locationReportDescriptionCol.setCellValueFactory((new PropertyValueFactory<>("Description")));
        locationReportTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        locationReportStartCol.setCellValueFactory((new PropertyValueFactory<>("StartTime")));
        locationReportEndCol.setCellValueFactory(new PropertyValueFactory<>("EndTime"));
        locationReportTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
    }

    /**
     * This method allows one to return to the main display screen when the exit button is clicked
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onExitLocationReport(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
