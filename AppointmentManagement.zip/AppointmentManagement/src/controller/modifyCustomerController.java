package controller;

import helper.CountrySQL;
import helper.CustomerSQL;
import helper.DivisionSQL;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Country;
import model.Division;
import model.customer;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the modifyCustomer screen
 */
public class modifyCustomerController implements Initializable {
    public final ArrayList<Integer> temp = new ArrayList<Integer>();
    public TextField modifyCustomerCustomerID;
    public TextField modifyCustomerCustomerName;
    public TextField modifyCustomerCustomerAddress;
    public TextField modifyCustomerPostalCode;
    public TextField modifyCustomerPhone;
    public ComboBox<Country> modifyCustomerCountry;
    public ComboBox<Division> modifyCustomerStateOrProvince;
    public Button modifyCustomerSave;
    public Button modifyCustomerExit;
    public Label modifyCustomerCommunication;
    public int countryID;
    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * This is an initialize method. It is basically a main method but it is for the modifyCustomer .fxml.
     *
     * @param url            the URL
     * @param resourceBundle the ResourceBundle
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CountrySQL.loadCountries(modifyCustomerCountry);
    }

    /**
     * This is method allows one to recieve the data for the selected customer and place it into the appropriate places.
     *
     * @param customer the customer object to be modified
     * @throws SQLException an SQLException
     */
    public void recieveCustomer(customer customer) throws SQLException {
        ResultSet ds = DivisionSQL.giveMeMatchingCountryAndDivisionInformation(customer.getDivisionID());
        while (ds.next()) {
            Division modifyDivisionFill = new Division(customer.getDivisionID(), ds.getString("Division"), ds.getInt("Country_ID"));
            modifyCustomerStateOrProvince.setValue(modifyDivisionFill);
            temp.add(modifyDivisionFill.getCountry_ID());
            modifyCustomerCountry.setItems(registers.getAllCountries());
            modifyCustomerCustomerID.setText(String.valueOf(customer.getCustomerID()));
            modifyCustomerCustomerName.setText(String.valueOf(customer.getCustomerName()));
            modifyCustomerCustomerAddress.setText((customer.getAddress()));
            modifyCustomerPostalCode.setText(String.valueOf(customer.getPostalCode()));
            modifyCustomerPhone.setText(customer.getPhone());
        }
        ResultSet countryIDRs = DivisionSQL.giveMeMatchingCountryIDFromDivisionID(customer);
        while (countryIDRs.next()) {
            countryID = countryIDRs.getInt("COUNTRY_ID");
        }
        ResultSet countryRS = CountrySQL.giveMeACountryFromID(countryID);
        while (countryRS.next()) {
            modifyCustomerCountry.setValue(new Country(countryRS.getInt("Country_ID"), countryRS.getString("Country")));
        }
    }

    /**
     * This method allows one to save a modified customer to the database.
     *
     * @param actionEvent the ActionEvent
     * @throws IOException  an IOException
     * @throws SQLException an SQLException
     */
    public void onSaveModifiedCustomer(ActionEvent actionEvent) throws SQLException, IOException {
        boolean blank = false;
        if (modifyCustomerCustomerName.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for the Customer Name");
            alert.showAndWait();
            blank = true;
        } else if (modifyCustomerCustomerAddress.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Address");
            alert.showAndWait();
            blank = true;
        } else if (modifyCustomerPostalCode.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Postal Code");
            alert.showAndWait();
            blank = true;
        } else if (modifyCustomerPhone.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Phone");
            alert.showAndWait();
            blank = true;
        } else if (modifyCustomerCountry.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Country");
            alert.showAndWait();
            blank = true;
        } else if (modifyCustomerStateOrProvince.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for division");
            alert.showAndWait();
            blank = true;
        }
        if (!blank) {
            CustomerSQL.UpdateCustomer(modifyCustomerCustomerName.getText(), modifyCustomerCustomerAddress.getText(), modifyCustomerPostalCode.getText(), modifyCustomerPhone.getText(), modifyCustomerStateOrProvince, Integer.parseInt(modifyCustomerCustomerID.getText()));
            root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
            stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }

    /**
     * This is method allows one to return to the main display screen without modifying a customer.
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onExitModifyCustomer(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    /**
     * This method loads all of the cities or provinces associated with the selected country into the modifyCustomerStateOrProvince combo box once the country is selected.
     *
     * @throws SQLException an SQLException
     */
    public void onCountrySelected() throws SQLException {
        DivisionSQL.loadDivisionInformation(modifyCustomerCountry, modifyCustomerStateOrProvince);
    }

    /**
     * This method makes sure that a country is selected before a division can be picked.
     */
    public void onDivisionIsClicked() {
        if (modifyCustomerCountry.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Select a country first before selecting a province or state from the divisions");
            alert.showAndWait();
        }
    }
}
