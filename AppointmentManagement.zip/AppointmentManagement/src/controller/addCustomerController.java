package controller;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import helper.CountrySQL;
import helper.CustomerSQL;
import helper.DivisionSQL;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Country;
import model.Division;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the add customer Controller
 */
public class addCustomerController implements Initializable {


    public TextField addCustomerCustomerID;
    public TextField addCustomerCustomerName;
    public TextField addCustomerCustomerAddress;
    public TextField addCustomerPostalCode;
    public TextField addCustomerPhone;
    public ComboBox<Country> addCustomerCountryComboBox;
    public ComboBox<Division> addCustomerStateOrProvince;
    public Button addCustomerSave;
    public Button addCustomerExit;
    public Label addCustomerCommunication;
    private Stage stage;
    private Scene scene;
    private Parent root;

    @Override
    /**
     * This is an initialize method and it is basically a main method but for the add customer screen
     * @param url the URL
     * @param rb the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle rb) {
        CountrySQL.loadCountries(addCustomerCountryComboBox);
        try {
            DivisionSQL.loadDivisionInformation(addCustomerCountryComboBox, addCustomerStateOrProvince);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            addCustomerCustomerID.setText(String.valueOf(registers.givemeaCustomerid()));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    /**
     * This method allows one to return to the main display screen without adding a new customer
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onExitAddCustomer(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    /**
     * This method adds the cities or provinces to the addCustomerStateOrProvince combo box when a country is selected
     *
     * @throws SQLException an SQLException
     */
    public void onCountrySelected() throws SQLException {
        DivisionSQL.loadDivisionInformation(addCustomerCountryComboBox, addCustomerStateOrProvince);

    }

    /**
     * This method makes sure that a country is selected before a division can be picked.
     */
    public void onDivisionClicked() {
        if (addCustomerCountryComboBox.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Select a country first before selecting a province or state from the divisions");
            alert.showAndWait();
        }
    }

    /**
     * This method allows one to save a new customer object when the save button is pressed and redirects them to the main display afterwards.
     *
     * @param actionEvent the ActionEvent
     * @throws SQLException an SQLException
     * @throws IOException  an IOException
     */
    public void onSaveCustomer(ActionEvent actionEvent) throws SQLException, IOException {
        CustomerSQL.addCustomer(addCustomerCustomerName, addCustomerCustomerAddress, addCustomerPostalCode, addCustomerPhone, addCustomerCountryComboBox, addCustomerStateOrProvince);
        root = FXMLLoader.load(getClass().getResource("/view/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
