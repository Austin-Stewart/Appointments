package controller;

import helper.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This class is the first one to run and starts the customer scheduling application
 */
public class Main extends Application {
    /**
     * This is the main method it is the first one to run and starts the customer scheduling application
     * @param args the args
     */
    public static void main(String[] args) {
        JDBC.openConnection();
        launch(args);
        JDBC.closeConnection();

    }

    @Override
    /**This is the start method. It starts the application and sets the stage.
     *@Param primaryStage this is the primaryStage
     *@throws Exception an Exception
     */
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        primaryStage.setTitle("Hello World");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }
}
