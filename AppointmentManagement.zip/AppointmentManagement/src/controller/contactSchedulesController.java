package controller;

import helper.AppointmentSQL;
import helper.ContactSQL;
import helper.timeManagement;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Contact;
import model.appointment;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the contactSchedules screen
 */
public class contactSchedulesController implements Initializable {
    public TableView appointmentTableView;
    public TableColumn contactAppointmentIdCol;
    public TableColumn contactAppointmenttitleCol;
    public TableColumn contactAppointmentTypeCol;
    public TableColumn contactAppointmentdescriptionCol;
    public TableColumn contactAppointmentstartDateAndTimeCol;
    public TableColumn contactAppointmentDateAndTimeEndCol;
    public TableColumn contactAppointmentCustomerIDCol;
    public Label currentLoggedInUser;
    public ComboBox<Contact> selectContactForSchedule;
    public Stage stage;
    public Scene scene;
    public Parent root;


    /**
     * This method adds all of the appointments for a selected contact to the appointmentTableView to display their schedule
     *
     * @throws SQLException an SQLException
     */
    public void onSelectContactForSchedule() throws SQLException {
        ResultSet res = AppointmentSQL.givemeAppointmentsWithMacthingContactID(selectContactForSchedule);
        while (res.next()) {
            registers.getAllappointments().add(new appointment(res.getInt("Appointment_ID"), res.getString("Title"), res.getString("Description"), res.getString("Location"), res.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(res.getDate("Start").toLocalDate(), res.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(res.getDate("End").toLocalDate(), res.getTime("End").toLocalTime()), res.getInt("Customer_ID"), res.getInt("User_ID"), res.getInt("Contact_ID")));
            appointmentTableView.setItems(registers.getAllAppointments());
        }

    }


    @Override
    /**
     * This is an initialize method and it is basically a main method but for the contactSchedules screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        currentLoggedInUser.setText(registers.getLoggedInUser().getUserName());
        ContactSQL.loadContacts(selectContactForSchedule);
        //Setting the values of the customer table so that it displays the right data
        contactAppointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("AppointmentID"));
        contactAppointmentCustomerIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerID"));
        contactAppointmentdescriptionCol.setCellValueFactory((new PropertyValueFactory<>("Description")));
        contactAppointmenttitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        contactAppointmentstartDateAndTimeCol.setCellValueFactory((new PropertyValueFactory<>("StartTime")));
        contactAppointmentDateAndTimeEndCol.setCellValueFactory(new PropertyValueFactory<>("EndTime"));
        contactAppointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
    }

    /**
     * This method allows one to return to the main display screen when the exit button is clicked
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onExitContactSchedules(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
