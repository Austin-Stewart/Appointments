package controller;

import controller.addAppointmentController;
import helper.AppointmentSQL;
import helper.CustomerSQL;
import helper.JDBC;
import helper.timeManagement;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.appointment;
import model.customer;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the controller.Main Display screen
 */
public class mainDisplayController implements Initializable {

    final Connection conn = JDBC.getConnection();
    public AnchorPane mainAnchorPane;
    public TableColumn<?, ?> mainDisplayCustomerIdCol;
    public TableColumn<?, ?> mainDisplayCustomerNameCol;
    public TableColumn<?, ?> mainDisplayAddressIdCol;
    public TableColumn<?, ?> mainDisplayPostalCodeCol;
    public TableColumn<?, ?> mainDisplayphoneCol;
    public TableColumn<?, ?> mainDisplayDivisionIDCol;
    public TableColumn<?, ?> mainDisplayAppointmentIDCol;
    public TableColumn<?, ?> mainDisplayAppointmentTitleCol;
    public TableColumn<?, ?> mainDisplayAppointmentCustomerIDCol;
    public TableColumn<?, ?> mainDisplayAppointmentDescriptionCol;
    public TableColumn<?, ?> mainDisplayAppointmentLocationCol;
    public TableColumn<?, ?> mainDisplayAppointmentTypeCol;
    public TableColumn<?, ?> mainDisplayappointmentStartCol;
    public TableColumn<?, ?> mainDisplayAppointmentEndCol;
    public Label mainDisplayCurrentLoggedInUserLbl;
    public Label mainDisplayUpcomingAppointmentsLbl;
    public TableView<appointment> mainDisplayAppointmentsTableView;
    public ObservableList<customer> customers;
    public TableColumn<?, ?> mainDisplayAppointmentContactCol;
    public RadioButton mainDisplayAllAppointmentsViewBtn;
    public RadioButton mainDisplayMonthlyAppointmentsViewBtn;
    public RadioButton mainDisplayWeeklyAppointmentsViewBtn;
    public TableView<customer> mainDisplayCustomerTableView;
    public Stage stage;
    public Scene scene;
    public Parent root;
    customer selected;
    String appointmentSQL = null;
    PreparedStatement prep = null;
    ResultSet appointmentRs = null;


    @FXML
    /**This method loads the customers from the database into the mainDisplayCustomerTableView.
     *@throws SQLException an SQLException
     */
    private void setupCustomerTable() throws SQLException {
        appointmentRs = CustomerSQL.giveMeCustomersFromDatabase();
        while (appointmentRs.next()) {
            registers.getAllcustomers().add(new customer(appointmentRs.getInt("Customer_ID"), appointmentRs.getString("Customer_Name"), appointmentRs.getString("Address"), appointmentRs.getString("Postal_Code"), appointmentRs.getString("Phone"), appointmentRs.getInt("Division_ID")));
            mainDisplayCustomerTableView.setItems(registers.getAllcustomers());
        }
    }

    @FXML
    /**This method loads the appointments from the database into the mainDisplayAppointmentsTableView.
     *@throws SQLException an SQLException
     */
    private void setupAppointmentTable() throws SQLException {
        registers.getAllappointments().clear();
        appointmentRs = AppointmentSQL.giveMeAppointmentInformation();
        while (appointmentRs.next()) {
            registers.getAllappointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));
        }
        mainDisplayAppointmentsTableView.setItems(registers.getAllappointments());
    }


    /**
     * This method allows one  to delete an appointment from the appointments table and database
     * @throws SQLException an SQLException
     */
    public void onDeleteAppointment() throws SQLException {
        try {
            appointment apt = mainDisplayAppointmentsTableView.getSelectionModel().getSelectedItem();
            Alert choice = new Alert(Alert.AlertType.CONFIRMATION);
            choice.setContentText("Are you sure?.");
            Optional<ButtonType> result = choice.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                ObservableList<appointment> selectedRow, appointment;
                appointment = mainDisplayAppointmentsTableView.getItems();
                selectedRow = mainDisplayAppointmentsTableView.getSelectionModel().getSelectedItems();
                if (selectedRow != null) {
                    for (model.appointment appointmentToDelete : selectedRow) {
                        Alert notify = new Alert(Alert.AlertType.INFORMATION);
                        notify.setContentText("You successfully deleted " + apt.getAppointmentID() + "|" + apt.getType());
                        notify.showAndWait();
                        registers.deleteAppointment(appointmentToDelete);
                        AppointmentSQL.deleteAppointment(apt);
                    }
                }
            }
        } catch (NoSuchElementException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("The list is empty quit trying to delete things.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No selection");
            alert.setContentText("Please select an item.");
            alert.showAndWait();
        }

    }


    /**
     * This method brings one to the modify Appointment fxml screen and sends the necessary data
     *
     * @param actionEvent the ActionEvent
     * @throws IOException  an IOException
     * @throws SQLException an SQLException
     */
    public void onModifyAppointment(ActionEvent actionEvent) throws IOException, SQLException {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/modifyAppointment.fxml"));
            loader.load();

            modifyAppointmentController mac = loader.getController();
            appointment apt = mainDisplayAppointmentsTableView.getSelectionModel().getSelectedItem();
            appointmentRs = AppointmentSQL.giveMeAppointmentsWithMatchingIDs(apt);
            while (appointmentRs.next()) {
                registers.setCreate_Date(appointmentRs.getDate("Create_Date").toString() + " " + appointmentRs.getTime("Create_Date").toString());
                registers.setCreatedBy(appointmentRs.getString("Created_By"));
            }
            if (apt != null) {
                mac.receiveAppointment(apt);
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                Parent scene = loader.getRoot();
                stage.setScene(new Scene(scene));
                stage.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No selected Part");
                alert.setContentText("No Part was chosen to be modified.");
                alert.showAndWait();
            }

        } catch (NoSuchElementException e) {
            //  Block of code to handle errors
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("The list is empty quit trying to delete things.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No selection");
            alert.setContentText("Please select an appointment that you want to modify.");
            alert.showAndWait();
        }
    }

    /**
     * This method brings one to the Add Appointment fxml screen and sends the necessary data
     *
     * @param actionEvent the ActionEvent
     * @throws IOException  an IOException
     * @throws SQLException an SQLException
     */
    public void onAddAppointment(ActionEvent actionEvent) throws IOException, SQLException {
        //Load the Part Screen fxml
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/AddAppointment.fxml"));
            loader.load();
            Alert choice = new Alert(Alert.AlertType.CONFIRMATION);
            choice.setContentText("Are you sure?");
            choice.showAndWait();
            Optional<ButtonType> result = choice.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                addAppointmentController aac = loader.getController();
                appointmentRs = CustomerSQL.giveMeCustomersWithMatchingIDs(selected);
                while (appointmentRs.next()) {
                    registers.setCreatedBy(appointmentRs.getString("Created_By"));
                }
                if (selected != null) {
                    aac.recieveCustomer(selected);
                    stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                    Parent scene = loader.getRoot();
                    stage.setScene(new Scene(scene));
                    stage.show();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("No selected Part");
                    alert.setContentText("No Part was chosen to be modified.");
                    alert.showAndWait();
                }
            }
        } catch (NoSuchElementException e) {
            //  Block of code to handle errors
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("The list is empty quit trying to delete things.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No selection");
            alert.setContentText("Please select a customer for the appointment to be made.");
            alert.showAndWait();
        }
    }

    /**
     * This method brings one to the Add Customer fxml screen
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void switchToAddScreen(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/AddCustomer.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method brings one to the modify Customer fxml screen and sends the necessary data
     *
     * @param actionEvent the ActionEvent
     * @throws SQLException an SQLException
     * @throws IOException  an IOException
     */
    public void switchToModifyCustomerScreen(ActionEvent actionEvent) throws IOException, SQLException {
        //Load the Part Screen fxml
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/modifyCustomer.fxml"));
            loader.load();

            modifyCustomerController mcc = loader.getController();
            customer par = mainDisplayCustomerTableView.getSelectionModel().getSelectedItem();
            appointmentRs = CustomerSQL.giveMeCustomersWithMatchingIDs(par);
            while (appointmentRs.next()) {
                registers.setCreatedBy(appointmentRs.getString("Created_By"));
            }
            if (par != null) {
                mcc.recieveCustomer(par);
                stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                Parent scene = loader.getRoot();
                stage.setScene(new Scene(scene));
                stage.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No selected Part");
                alert.setContentText("No Part was chosen to be modified.");
                alert.showAndWait();
            }
        } catch (NoSuchElementException e) {
            //  Block of code to handle errors
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("There are no customers in the table.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No selection");
            alert.setContentText("Please select a customer to modify.");
            alert.showAndWait();
        }
    }

    /**
     * This method allows one to delete a customer from the database and customer table
     *
     * @throws SQLException an SQLException
     */
    public void deleteCustomer() throws SQLException {

        boolean doesNotHaveAppointments = true;
        appointmentRs = AppointmentSQL.giveMeAppointmentInformation();
        while (appointmentRs.next()) {

            if (selected.getCustomerID() == appointmentRs.getInt("Customer_ID")) {
                doesNotHaveAppointments = false;
            }
        }

        if (doesNotHaveAppointments) {
            try {
                CustomerSQL.DeleteCustomer(mainDisplayCustomerTableView);
                Alert choice = new Alert(Alert.AlertType.CONFIRMATION);
                choice.setContentText("Are you sure?");
                Optional<ButtonType> result = choice.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    ObservableList<customer> selectedRow, customer;
                    customers = mainDisplayCustomerTableView.getItems();
                    selectedRow = mainDisplayCustomerTableView.getSelectionModel().getSelectedItems();
                    if (selectedRow != null) {
                        for (customer customerToDelete : selectedRow) {
                            Alert notify = new Alert(Alert.AlertType.CONFIRMATION);
                            notify.setContentText("You successfully deleted " + customerToDelete.getCustomerName());
                            notify.showAndWait();
                            registers.deleteCustomer(customerToDelete);
                        }
                    }
                }
            } catch (NoSuchElementException e) {
                //  Block of code to handle errors
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Empty List");
                alert.setContentText("The list is empty quit trying to delete things.");
                alert.showAndWait();
            } catch (NullPointerException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No selection");
                alert.setContentText("Please select an item.");
                alert.showAndWait();
            }
        }
        if (!doesNotHaveAppointments) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Appointments Left");
            alert.setContentText("You must delete all associated appointments first before deleting this customer.");
            alert.showAndWait();
        }
    }

    @Override
    /**
     * This is an initialize method and it is basically a main method but for the MainDisplay screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        mainDisplayCustomerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        mainDisplayCustomerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        mainDisplayAddressIdCol.setCellValueFactory((new PropertyValueFactory<>("Address")));
        mainDisplayPostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        mainDisplayphoneCol.setCellValueFactory((new PropertyValueFactory<>("Phone")));
        mainDisplayDivisionIDCol.setCellValueFactory(new PropertyValueFactory<>("divisionID"));
        mainDisplayCurrentLoggedInUserLbl.setText(registers.getLoggedInUser().getUserName());
        mainDisplayAppointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        mainDisplayAppointmentTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        mainDisplayAppointmentCustomerIDCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        mainDisplayAppointmentDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        mainDisplayAppointmentLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        mainDisplayAppointmentTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        mainDisplayappointmentStartCol.setCellValueFactory(new PropertyValueFactory<>("StartTime"));
        mainDisplayAppointmentEndCol.setCellValueFactory(new PropertyValueFactory<>("EndTime"));
        mainDisplayAppointmentContactCol.setCellValueFactory(new PropertyValueFactory<>("ContactID"));
        System.out.println(registers.isIsWithinFifteenMinutes());
        if(registers.isIsWithinFifteenMinutes() == true){
            mainDisplayUpcomingAppointmentsLbl.setText("You have upcoming appointments within 15 minutes");
        }
        try {
            setupCustomerTable();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            setupAppointmentTable();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            setupAppointmentTable();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }

    /**
     * This method allows one to view every appointment within the database.
     *
     * @throws SQLException an SQLException
     */
    public void onViewAllAppointments() throws SQLException {
        setupAppointmentTable();
    }

    /**
     * This method allows one to view every appointment within the current month.
     *
     * @throws SQLException an SQLException
     */
    public void onViewMonthlyAppointments() throws SQLException {
        appointmentRs = AppointmentSQL.giveMeMonthlyAppointments();
        while (appointmentRs.next()) {
            String start = appointmentRs.getString("Start");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime local = LocalDateTime.parse(start, formatter);
            Month month = local.getMonth();
            LocalDate currentdate = LocalDate.now();
            if (currentdate.getMonth() == month)
                registers.getAllMonthlyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));
            mainDisplayAppointmentsTableView.setItems(registers.getAllMonthlyAppointments());
        }
    }

    /**
     * This method allows one to view every appointment in the database which occurs within the current week.
     *
     * @throws SQLException an SQLException
     */
    public void onviewWeeklyAppointments() throws SQLException {
        registers.getAllWeeklyAppointments().clear();
//        appointmentRs = AppointmentSQL.giveMeWeeklyAppointments();
//        while (appointmentRs.next()) {
//            System.out.println(appointmentRs.getDate("Start"));
//            registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));
//        }
//        mainDisplayAppointmentsTableView.setItems(registers.getAllWeeklyAppointments());
        appointmentRs = AppointmentSQL.giveMeAppointmentInformation();

        registers.getAllWeeklyAppointments().clear();
        DayOfWeek dayOfWeek = LocalDateTime.now().getDayOfWeek();
        while(appointmentRs.next()){
                if(dayOfWeek.toString().equals("SUNDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(1)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(6))){
                registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

            }}
            else if(dayOfWeek.toString().equals("MONDAY")){
                if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(2)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(5))){
                    registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                }}
                else if(dayOfWeek.toString().equals("TUESDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(3)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(4))){
                        registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                    }}
                else if(dayOfWeek.toString().equals("WEDNESDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(4)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(3))){
                        registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                    }}
                else if(dayOfWeek.toString().equals("THURSDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(5)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(2))){
                        registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                    }}
                else if(dayOfWeek.toString().equals("FRIDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(6)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(1))){
                        registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                    }}
                else if(dayOfWeek.toString().equals("SATURDAY")){
                    if(timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isAfter(LocalDateTime.now().minusDays(7)) && timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(),appointmentRs.getTime("Start").toLocalTime()).isBefore(LocalDateTime.now().plusDays(0))){
                        registers.getAllWeeklyAppointments().add(new appointment(appointmentRs.getInt("Appointment_ID"), appointmentRs.getString("Title"), appointmentRs.getString("Description"), appointmentRs.getString("Location"), appointmentRs.getString("Type"), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("Start").toLocalDate(), appointmentRs.getTime("Start").toLocalTime()), timeManagement.giveMeSelectedTimeInLocal(appointmentRs.getDate("End").toLocalDate(), appointmentRs.getTime("End").toLocalTime()), appointmentRs.getInt("Customer_ID"), appointmentRs.getInt("User_ID"), appointmentRs.getInt("Contact_ID")));

                    }}
            }
        mainDisplayAppointmentsTableView.setItems(registers.getAllWeeklyAppointments());
    }

    /**
     * This method brings one to the report screen which displays appointments by month and type
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onViewByMonthAndTypeReport(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/appointmentsByTypeAndMonth.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method brings one to login screen so that one can login with a different account
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onLogOff(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method brings one to the report screen which shows the appointment schedules for each contact
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onViewContactSchedules(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/contactSchedules.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * This method stores the value of the selected customer from the customer table
     */
    public void onCustomerSelected() {
        try {
            selected = mainDisplayCustomerTableView.getSelectionModel().getSelectedItem();
        } catch (NoSuchElementException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("No customer was selected.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No selection");
            alert.setContentText("No customer was selected.");
            alert.showAndWait();
        }
    }

    /**
     * This method brings one to the additional report screen which displays appointments by location
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onViewReportByLocation(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/view/appointmentsByLocation.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
