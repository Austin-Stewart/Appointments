package controller;

import helper.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the modifyAppointment screen
 */
public class modifyAppointmentController implements Initializable {


    private final DateTimeFormatter ISOStandardFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");//ISO standard time format

    public ComboBox<User> selectUserForIDComboBox;
    public ComboBox<customer> selectCustomerID;
    public TextField modifyAppointmentTitleText;
    public TextField modifyAppointmentDescriptionText;
    public ComboBox<Contact> modifyAppointmentContact;
    public DatePicker modifyAppointmentDate;
    public TextField appointmentIDText;
    public ComboBox<String> modifyAppointmentType;
    public ComboBox<LocalTime> modifyAppointmentStartTime;
    public ComboBox<LocalTime> modifyAppointmentEndTime;
    public ComboBox<String> modifyAppointmentLocation;
    public Label modifyOverlapAlertLbl;
    public TextField modifyAppointmentAppointmentIDText;
    public boolean isOverlapping = false;
    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * This is an initialize method. It is basically a main method but it is for the modifyAppointment .fxml.
     *
     * @param url            the URL
     * @param resourceBundle the ResourceBundle
     */
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupLocationBox();
        CustomerSQL.loadCustomers(selectCustomerID);
        UserSQL.loadUsers(selectUserForIDComboBox);
        modifyAppointmentType.setItems(registers.getAllAppointmentTypes());
        ContactSQL.loadContacts(modifyAppointmentContact);
        timeManagement.fillTimeLists(modifyAppointmentStartTime, modifyAppointmentEndTime);

    }


    /**
     * This method recieves all of the data from the selected appointments and places it into the necessary places.
     *
     * @param apt the appointment object
     * @throws SQLException an SQLException
     */
    public void receiveAppointment(appointment apt) throws SQLException {
        String userName = UserSQL.getUserName(String.valueOf(apt.getUserID()));
        modifyAppointmentAppointmentIDText.setText(String.valueOf(apt.getAppointmentID()));
        assert userName != null;
        selectUserForIDComboBox.setValue(new User(userName, apt.getUserID()));
        selectCustomerID.setValue(new customer(apt.getCustomerID()));
        modifyAppointmentTitleText.setText(String.valueOf(apt.getTitle()));
        modifyAppointmentDescriptionText.setText(String.valueOf(apt.getDescription()));
        modifyAppointmentLocation.setValue(apt.getLocation());
        modifyAppointmentType.setValue(apt.getType());
        ResultSet contactrs = ContactSQL.loadContactsInformationBasedOnID(apt);
        while (contactrs.next()) {
            modifyAppointmentContact.setValue(new Contact(contactrs.getInt("Contact_ID"), contactrs.getString("Contact_Name"), contactrs.getString("Email")));
            //Pulls out the time of a LocalDateTime and puts it into a string
            LocalDate startDate = dateTimeConnector.StartDateExtractor(apt);
            LocalTime startTime = dateTimeConnector.StartTimeExtractor(apt);
            LocalDate endDate = dateTimeConnector.EndDateExtractor(apt);
            LocalTime endTime = dateTimeConnector.EndTimeExtractor(apt);
            modifyAppointmentStartTime.setValue(startTime);
            modifyAppointmentDate.setValue(startDate);
            modifyAppointmentEndTime.setValue(endTime);
        }
    }


    /**
     * This method loads all of the locations into the   modifyAppointmentLocation combo box.
     */
    private void setupLocationBox() {
        modifyAppointmentLocation.setItems(registers.getAllLocations());
    }


    /**
     * This method loads allows one to save a modified appointment to the database if the appointment does not overlap the time of another appointment.
     *
     * @param actionEvent the ActionEvent
     * @throws IOException  an IOException
     * @throws SQLException an SQLException
     */
    public void onSaveModifiedAppointment(ActionEvent actionEvent) throws SQLException, IOException {
        try {
            LocalDateTime selectedStartinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(modifyAppointmentDate.getValue().getYear(), modifyAppointmentDate.getValue().getMonth(), modifyAppointmentDate.getValue().getDayOfMonth()), LocalTime.of(modifyAppointmentStartTime.getValue().getHour(), modifyAppointmentStartTime.getValue().getMinute()));
            LocalDateTime selectedEndinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(modifyAppointmentDate.getValue().getYear(), modifyAppointmentDate.getValue().getMonth(), modifyAppointmentDate.getValue().getDayOfMonth()), LocalTime.of(modifyAppointmentEndTime.getValue().getHour(), modifyAppointmentEndTime.getValue().getMinute()));
            ResultSet appointmentInformationrs = AppointmentSQL.giveMeAppointmentInformation();

            while (appointmentInformationrs.next()) {
                System.out.println(!AppointmentSQL.appointmentWithIDExists(Integer.parseInt(modifyAppointmentAppointmentIDText.getText())));
                if (selectedStartinUTC.isAfter(dateTimeConnector.dateTime(appointmentInformationrs.getDate("Start"), appointmentInformationrs.getTime("Start"))) && selectedStartinUTC.isBefore(dateTimeConnector.dateTime(appointmentInformationrs.getDate("End"), appointmentInformationrs.getTime("End"))) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(modifyAppointmentAppointmentIDText.getText())) || selectedEndinUTC.isAfter(dateTimeConnector.dateTime(appointmentInformationrs.getDate("Start"), appointmentInformationrs.getTime("Start"))) && selectedStartinUTC.isBefore(dateTimeConnector.dateTime(appointmentInformationrs.getDate("End"), appointmentInformationrs.getTime("End"))) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(modifyAppointmentAppointmentIDText.getText()))) {
                    Alert overlapAlert = new Alert(Alert.AlertType.WARNING);
                    overlapAlert.setContentText("This appointment overlaps with the following appointment" + "|" + appointmentInformationrs.getInt("Appointment_ID") + "|" + appointmentInformationrs.getString("Description"));
                    overlapAlert.showAndWait();
                    isOverlapping = true;
                    modifyOverlapAlertLbl.setText("This Appointment Overlaps with another");

                }

            }
            if (!isOverlapping) {
                AppointmentSQL.updateAppointment(modifyOverlapAlertLbl, modifyAppointmentAppointmentIDText, modifyAppointmentTitleText, modifyAppointmentDescriptionText, modifyAppointmentLocation, modifyAppointmentType, modifyAppointmentDate, selectedStartinUTC, selectedEndinUTC, selectCustomerID, selectUserForIDComboBox, modifyAppointmentContact);
                root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
                stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }

        } finally {

        }
    }

    /**
     * This method allows one to return to the main display screen without modifying an appointment when the exit button is pressed.
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onCancelAppointment(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}