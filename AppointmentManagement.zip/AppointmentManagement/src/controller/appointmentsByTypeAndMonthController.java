package controller;

import helper.AppointmentSQL;
import helper.textSetterInterface;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the appointmentsByTypeAndMonth screen
 */
public class appointmentsByTypeAndMonthController implements Initializable {
    public static int InPerson = 0;
    public static int Online = 0;
    public static int Telephone = 0;
    public static int NewAppointment = 0;
    public static int KickoffMeeting = 0;
    public static int CloseoutMeeting = 0;
    public static int QualityAssurance = 0;
    public ComboBox<String> monthSelectionBox;
    public Label inPersonCountLbl;
    public Label OnlineCountLbl;
    public Label telephoneCountLbl;
    /**
     * This lambda expression is used to set the text for the number of telephone appointments occurring during any given month
     */
    final textSetterInterface setText = Telephone -> telephoneCountLbl.setText(String.valueOf(Telephone));
    public Label NewCountLbl;
    public Label kickoffCountLbl;
    public Label closeoutCountLbl;
    public Label qualityAssuranceCountLbl;


    /**
     * @param inPerson the number of Inperson appointments to set
     */
    public static void setInPerson(int inPerson) {
        InPerson = inPerson;
    }

    /**
     * @param online the number of Online appointments to set
     */
    public static void setOnline(int online) {
        Online = online;
    }

    /**
     * @param telephone the number of Telephone appointments to set
     */
    public static void setTelephone(int telephone) {
        Telephone = telephone;
    }


    /**
     * @param newAppointment the number of newAppointments to set
     */
    public static void setNewAppointment(int newAppointment) {
        NewAppointment = newAppointment;
    }

    /**
     * @param kickoffMeeting the number of kickoffMeetings to set
     */
    public static void setKickoffMeeting(int kickoffMeeting) {
        KickoffMeeting = kickoffMeeting;
    }

    /**
     * @param closeoutMeeting the number of CloseoutMeeting appointments to set
     */
    public static void setCloseoutMeeting(int closeoutMeeting) {
        CloseoutMeeting = closeoutMeeting;
    }

    /**
     * @param qualityAssurance the number of QualityAssurance appointments to set
     */
    public static void setQualityAssurance(int qualityAssurance) {
        QualityAssurance = qualityAssurance;

    }

    @Override
    /**
     * This is an initialize method and it is basically a main method but for the appointmentsByTypeAndMonth screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        monthSelectionBox.setItems(registers.getAllMonths());
    }

    /**
     * This method sets the text of the necessary labels to the number of appointments which are occuring during a given month for each type of appointment
     *
     * @throws SQLException an SQLException
     */
    public void onMonthSelected() throws SQLException {
        int refreshedInPerson = 0;
        int refreshedOnline = 0;
        int refreshedTelephone = 0;
        int refreshedNewAppointment = 0;
        int refreshedKickoffMeeting = 0;
        int refreshedCloseoutMeeting = 0;
        int refreshedQualityAssurance = 0;
        Telephone = 0;
        InPerson = 0;
        Online = 0;
        NewAppointment = 0;
        KickoffMeeting = 0;
        CloseoutMeeting = 0;
        QualityAssurance = 0;
        telephoneCountLbl.setText(String.valueOf(0));
        inPersonCountLbl.setText(String.valueOf(0));
        OnlineCountLbl.setText(String.valueOf(0));
        NewCountLbl.setText(String.valueOf(0));
        kickoffCountLbl.setText(String.valueOf(0));
        closeoutCountLbl.setText(String.valueOf(0));
        qualityAssuranceCountLbl.setText(String.valueOf(0));
        ResultSet appointmentsWithGivenMonthResultSet = AppointmentSQL.giveMeAppointmentsWithGivenMonth(monthSelectionBox);
        while (appointmentsWithGivenMonthResultSet.next()) {
            switch (appointmentsWithGivenMonthResultSet.getString("Type")) {
                case "In-Person":
                    refreshedInPerson = refreshedInPerson + 1;
                    InPerson = refreshedInPerson;

                    break;
                case "Online":
                    refreshedOnline = refreshedOnline + 1;
                    Online = refreshedOnline + 1;

                    break;
                case "Telephone":
                    refreshedTelephone = refreshedTelephone + 1;
                    Telephone = refreshedTelephone;

                    break;
                case "New Appointment":
                    refreshedNewAppointment = refreshedNewAppointment + 1;
                    NewAppointment = refreshedNewAppointment;

                    break;
                case "Kickoff Meeting":
                    refreshedKickoffMeeting = refreshedKickoffMeeting + 1;
                    KickoffMeeting = refreshedKickoffMeeting;

                    break;
                case "Closeout Meeting":
                    refreshedCloseoutMeeting = refreshedCloseoutMeeting + 1;
                    CloseoutMeeting = refreshedCloseoutMeeting;

                    break;
                case "Quality Assurance":
                    refreshedQualityAssurance = refreshedQualityAssurance + 1;
                    QualityAssurance = refreshedQualityAssurance;

                    break;
            }
            setQualityAssurance(refreshedQualityAssurance);
            setCloseoutMeeting(refreshedCloseoutMeeting);
            setKickoffMeeting(refreshedKickoffMeeting);
            setNewAppointment(refreshedNewAppointment);
            setTelephone(refreshedTelephone);
            setOnline(refreshedOnline);
            setInPerson(InPerson);
        }
        setText.setText(Telephone);
        inPersonCountLbl.setText(String.valueOf(InPerson));
        OnlineCountLbl.setText(String.valueOf(Online));
        NewCountLbl.setText(String.valueOf(NewAppointment));
        kickoffCountLbl.setText(String.valueOf(KickoffMeeting));
        closeoutCountLbl.setText(String.valueOf(CloseoutMeeting));
        qualityAssuranceCountLbl.setText(String.valueOf(QualityAssurance));
    }

    /**
     * This method allows one to return to the main display screen when the exit button is clicked
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     */
    public void onExitTypeReport(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/MainDisplay.fxml"));
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
