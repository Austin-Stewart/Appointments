package controller;

import helper.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Contact;
import model.User;
import model.customer;
import model.registers;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

/**
 * This class controls all of the actions in the add Appointment Controller
 */
public class addAppointmentController implements Initializable {
    private final DateTimeFormatter isoFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");//ISO standard time format
    public TextField addAppointmentIDText;
    public ComboBox<User> addAppointmentUserId;
    public ComboBox<customer> addAppointmentCustomerId;
    public TextField addAppointmentTitleText;
    public TextField addAppointmentDescriptionText;
    public ComboBox<Contact> addAppointmentContactSelector;
    public ComboBox<String> addAppointmentType;
    public DatePicker addAppointmentDatePicker;
    public ComboBox<LocalTime> addAppointmentStartTimeSelector;
    public ComboBox<LocalTime> addAppointmentEndTimeSelector;
    public Label upperTimezoneLabel;
    public Label lowerTimezoneLabel;
    public Label overlapAlertLbl;
    public ComboBox<String> appointmentLocationSelector;
    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * This method recieves all of the necessary data from the selected customer and inputs it into the proper areas
     *
     * @param customer the customer
     */
    public void recieveCustomer(customer customer) {

        addAppointmentCustomerId.setValue(new customer(customer.getCustomerID()));
        addAppointmentUserId.setValue(new User(registers.getLoggedInUser().getUserName(), registers.getLoggedInUser().getUser_ID()));
    }

    /**
     * This method places all of the locations which are allowed to be selected into the appointmentLocationSelector combo box
     */
    private void setupLocationBox() {
        appointmentLocationSelector.setItems(registers.getAllLocations());
    }

    /**
     * This method allows one to save an appointment to the database if it does not have a time which overlaps with another appointment
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     * @throws SQLException an SQLException
     **/
    public void onSaveAppointment(ActionEvent actionEvent) throws IOException, SQLException {
        boolean isOverlapping = false;
        LocalDateTime selectedStartInUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(addAppointmentDatePicker.getValue().getYear(), addAppointmentDatePicker.getValue().getMonth(), addAppointmentDatePicker.getValue().getDayOfMonth()), addAppointmentStartTimeSelector.getValue());
        LocalDateTime selectedEndInUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(addAppointmentDatePicker.getValue().getYear(), addAppointmentDatePicker.getValue().getMonth(), addAppointmentDatePicker.getValue().getDayOfMonth()), addAppointmentEndTimeSelector.getValue());
        AppointmentSQL.addAppointment(addAppointmentUserId, addAppointmentCustomerId, appointmentLocationSelector, addAppointmentTitleText, addAppointmentDescriptionText, addAppointmentContactSelector, addAppointmentType, addAppointmentDatePicker, addAppointmentStartTimeSelector, addAppointmentEndTimeSelector, overlapAlertLbl, addAppointmentIDText);
        ResultSet appointmentInformationrs = AppointmentSQL.giveMeAppointmentInformation();
        while (appointmentInformationrs.next()) {
            if (selectedStartInUTC.isAfter(dateTimeConnector.dateTime(appointmentInformationrs.getDate("Start"), appointmentInformationrs.getTime("Start"))) && selectedStartInUTC.isBefore(dateTimeConnector.dateTime(appointmentInformationrs.getDate("End"), appointmentInformationrs.getTime("End"))) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(addAppointmentIDText.getText())) || selectedEndInUTC.isAfter(dateTimeConnector.dateTime(appointmentInformationrs.getDate("Start"), appointmentInformationrs.getTime("Start"))) && selectedStartInUTC.isBefore(dateTimeConnector.dateTime(appointmentInformationrs.getDate("End"), appointmentInformationrs.getTime("End"))) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(addAppointmentIDText.getText()))) {
                Alert overlapAlert = new Alert(Alert.AlertType.WARNING);
                overlapAlert.setContentText("This appointment overlaps with the following appointment" + "|" + appointmentInformationrs.getInt("Appointment_ID") + "|" + appointmentInformationrs.getString("Description"));
                overlapAlert.showAndWait();
                isOverlapping = true;
            }
            if (isOverlapping == false) {
                root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
                stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            }

        }
    }

    /**
     * This method allows one to return to the main display screen without adding an appointment
     *
     * @param actionEvent the ActionEvent
     * @throws IOException an IOException
     **/
    public void onCancelAppointment(ActionEvent actionEvent) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/View/MainDisplay.fxml"));
        stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    /**
     * This is an initialize method and it is basically a main method but for the add appointment screen
     * @param url the URL
     * @param resourceBundle the ResourceBundle
     **/
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setupLocationBox();
        timeManagement.fillTimeLists(addAppointmentStartTimeSelector, addAppointmentEndTimeSelector);
        addAppointmentType.setItems(registers.getAllAppointmentTypes());
        lowerTimezoneLabel.setText(ZoneId.systemDefault().toString());
        upperTimezoneLabel.setText(ZoneId.systemDefault().toString());
        UserSQL.loadUsers(addAppointmentUserId);
        ContactSQL.loadContacts(addAppointmentContactSelector);
        CustomerSQL.loadCustomers(addAppointmentCustomerId);
        try {
            addAppointmentIDText.setText(String.valueOf(registers.giveMeAnAppointmentId()));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * This method allows one to get the start date of an appointment once selected
     **/
    public void getStartDate() {
        LocalDate date = addAppointmentDatePicker.getValue();
    }
}