package helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This class contains methods which allow one to retrieve statement and PreparedStatement objects
 */
public class DBQuery {
    private static Statement statement;
    private static PreparedStatement preparedStatement;

    /**
     * @return statement the statement
     */
    public static Statement getStatement() {
        return statement;
    }

    /**
     * @param conn the Connection to set
     * @throws SQLException an SQLException
     */
    public static void setStatement(Connection conn) throws SQLException {
        statement = conn.createStatement();
    }

    /**
     * @param conn         the Connection to set
     * @param sqlStatement the SQLStatement to set
     * @throws SQLException an SQLException
     */
    public static void setPreparedStatement(Connection conn, String sqlStatement) throws SQLException {
        statement = conn.prepareStatement(sqlStatement);

    }

    /**
     * @return preparedStatement the PreparedStatement
     */
    public static PreparedStatement getPreparedStatement() {
        return preparedStatement;
    }
}
