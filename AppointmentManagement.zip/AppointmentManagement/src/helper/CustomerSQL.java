package helper;

import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Country;
import model.Division;
import model.customer;
import model.registers;

import java.sql.*;

public class CustomerSQL {
    /**
     * This method allows one to save a new customer to the database
     *
     * @param addCustomerCustomerName    the customer name
     * @param addCustomerCustomerAddress the customer address
     * @param addCustomerPostalCode      the postal code
     * @param addCustomerPhone           the customer phone number
     * @param addCustomerCountryComboBox the combobox with the country selected
     * @param addCustomerStateOrProvince the combobox with the selected state or province
     * @throws SQLException an SQLException
     */
    public static void addCustomer(TextField addCustomerCustomerName, TextField addCustomerCustomerAddress, TextField addCustomerPostalCode, TextField addCustomerPhone, ComboBox<Country> addCustomerCountryComboBox, ComboBox<Division> addCustomerStateOrProvince) throws SQLException {
        if (addCustomerCustomerName.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for the Customer Name");
            alert.showAndWait();
        } else if (addCustomerCustomerAddress.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Address");
            alert.showAndWait();
        } else if (addCustomerPostalCode.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Postal Code");
            alert.showAndWait();
        } else if (addCustomerPhone.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Phone");
            alert.showAndWait();
        } else if (addCustomerCountryComboBox.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Country");
            alert.showAndWait();
        } else if (addCustomerStateOrProvince.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for division");
            alert.showAndWait();
        }
        if (!addCustomerCustomerName.getText().isBlank() && !addCustomerCustomerAddress.getText().isBlank() && !addCustomerPostalCode.getText().isBlank() && !addCustomerPhone.getText().isBlank() && !addCustomerCountryComboBox.getSelectionModel().isEmpty() && !addCustomerStateOrProvince.getSelectionModel().isEmpty()) {
            Connection conn = JDBC.getConnection();
            String query = " insert into customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID ,Create_Date,Last_Update,Created_By,Last_Updated_By)"
                    + " values (NULL,?, ?, ?, ?, ?,?,?,?,?)";

            // create the mysql insert preparedstatement
            PreparedStatement preparedStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            preparedStmt.setString(1, addCustomerCustomerName.getText());
            preparedStmt.setString(2, addCustomerCustomerAddress.getText());
            preparedStmt.setString(3, addCustomerPostalCode.getText());
            preparedStmt.setString(4, addCustomerPhone.getText());
            preparedStmt.setInt(5, addCustomerStateOrProvince.getValue().getDivisionID());
            preparedStmt.setString(6, timeManagement.giveMeaCreateDate().toString());
            preparedStmt.setString(7, timeManagement.giveMeALastUpdate().toString());
            preparedStmt.setString(8, registers.getLoggedInUser().getUserName());
            preparedStmt.setString(9, registers.getLoggedInUser().getUserName());
            // execute the preparedstatement
            preparedStmt.execute();

        }


    }

    /**
     * This method allows one to UPDATE a customer within the database.
     *
     * @param modifyCustomerCustomerName    the customer name
     * @param modifyCustomerCustomerAddress the customer address
     * @param modifyCustomerCustomerID      the customer ID
     * @param modifyCustomerPhone           the customer phone
     * @param modifyCustomerPostalCode      the customer postal code
     * @param modifyCustomerStateOrProvince the customer state or province
     * @throws SQLException an SQLException
     */
    public static void UpdateCustomer(String modifyCustomerCustomerName, String modifyCustomerCustomerAddress, String modifyCustomerPostalCode, String modifyCustomerPhone, ComboBox<Division> modifyCustomerStateOrProvince, int modifyCustomerCustomerID) throws SQLException {
        String updateString = " UPDATE Customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ?, Created_By = ?, Last_Update = ?, Last_Updated_By = ? Where Customer_ID = ?";
        Connection conn = JDBC.getConnection();
        PreparedStatement update = conn.prepareStatement(updateString);
        update.setString(1, modifyCustomerCustomerName);
        update.setString(2, modifyCustomerCustomerAddress);
        update.setString(3, modifyCustomerPostalCode);
        update.setString(4, modifyCustomerPhone);
        update.setInt(5, modifyCustomerStateOrProvince.getSelectionModel().getSelectedItem().getDivisionID());
        update.setString(6, registers.getCreatedBy());
        update.setString(7, timeManagement.giveMeALastUpdate().toString());
        update.setString(8, registers.getLoggedInUser().getUserName());
        update.setInt(9, modifyCustomerCustomerID);
        update.executeUpdate();
    }

    public static void DeleteCustomer(TableView<customer> mainDisplayCustomerTableView) throws SQLException {
        customer cust = mainDisplayCustomerTableView.getSelectionModel().getSelectedItem();
        Connection conn = JDBC.getConnection();
        String query = " DELETE FROM CUSTOMERS WHERE Customer_ID =" + cust.getCustomerID();
        PreparedStatement preparedStmt = conn.prepareStatement(query);
        preparedStmt.execute();
    }

    /**
     * This method loads all of the customer objects into the the customer comboboxes.
     *
     * @param selectCustomerIDComboBox the customer combobox with the ID from the customer that one needs
     */
    public static void loadCustomers(ComboBox<customer> selectCustomerIDComboBox) {
        registers.getAllcustomers().clear();
        try {
            String sql = "SELECT * FROM customers";
            Connection conn = JDBC.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet allCustomerInformationResultSet = pst.executeQuery(sql);
            while (allCustomerInformationResultSet.next()) {
                registers.addcustomer(new customer(allCustomerInformationResultSet.getInt("Customer_ID"), allCustomerInformationResultSet.getString("Customer_Name"), allCustomerInformationResultSet.getString("Address"), allCustomerInformationResultSet.getString("Postal_Code"), allCustomerInformationResultSet.getString("Phone"), allCustomerInformationResultSet.getInt("Division_ID")));
                selectCustomerIDComboBox.setItems(registers.getAllcustomers());
            }
        } catch (SQLException ignored) {

        }
    }

    public static ResultSet giveMeCustomersFromDatabase() throws SQLException {
        Connection conn = JDBC.getConnection();
        registers.getAllcustomers().clear();
        String appointmentSQL = "SELECT * FROM java_project.customers";
        PreparedStatement prep = conn.prepareStatement(appointmentSQL);
        ResultSet allCustomerInformationResultSet = prep.executeQuery();
        return allCustomerInformationResultSet;
    }

    public static ResultSet giveMeCustomersWithMatchingIDs(customer selected) throws SQLException {
        Connection conn = JDBC.getConnection();
        String customerSQL = "SELECT * FROM Customers Where Customer_ID = " + selected.getCustomerID();
        PreparedStatement prep = conn.prepareStatement(customerSQL);
        ResultSet customerWithMatchingCustomerIDResultSet = prep.executeQuery();
        return customerWithMatchingCustomerIDResultSet;
    }
}
