package helper;

import javafx.scene.control.ComboBox;
import model.Country;
import model.registers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CountrySQL {
    /**
     * This method loads all of the countries into a desired combo box.
     *
     * @param countryComboBox the combobox which is used to select the customers country
     */
    public static void loadCountries(ComboBox<Country> countryComboBox) {
        registers.getAllCountries().clear();
        try {
            String sql = "SELECT * FROM Countries";
            Connection conn = JDBC.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet allCountryInformationResultSet = pst.executeQuery(sql);
            while (allCountryInformationResultSet.next()) {
                String lname = allCountryInformationResultSet.getString("Country");

                registers.addCountry(allCountryInformationResultSet.getInt("Country_ID"), allCountryInformationResultSet.getString("Country"));
                countryComboBox.setItems(registers.getAllCountries());
            }
        } catch (SQLException ignored) {

        }
    }

    /**
     * This method gives on the name of the country with a matching country id
     *
     * @param countryID the countryID
     * @return countryNamepst.executeQuery(countrySQL) the resultset which contains the country name with a matching countryID
     * @throws SQLException an SQLException
     */
    public static ResultSet giveMeACountryFromID(int countryID) throws SQLException {
        Connection conn = JDBC.getConnection();
        String countrySQL = "SELECT * FROM countries WHERE Country_ID=" + countryID;
        Connection countryNameconn = JDBC.getConnection();
        PreparedStatement countryNamepst = conn.prepareStatement(countrySQL);
        return countryNamepst.executeQuery(countrySQL);
    }
}
