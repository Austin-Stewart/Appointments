package helper;

import javafx.scene.control.ComboBox;
import model.User;
import model.registers;

import java.sql.*;

public class UserSQL {
    /**
     * This method loads all of the user objects into a desired combo box.
     *
     * @param selectUserForIDComboBox the combobox where the User ID is obtained from
     */
    public static void loadUsers(ComboBox<User> selectUserForIDComboBox) {
        registers.getAllUsers().clear();
        try {
            String sql = "SELECT * FROM users";
            Connection conn = JDBC.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet allUserInformationResultSet = pst.executeQuery(sql);
            while (allUserInformationResultSet.next()) {
                registers.addUser(new User(allUserInformationResultSet.getInt("User_ID"), allUserInformationResultSet.getString("User_Name"), allUserInformationResultSet.getString("Password")));
                selectUserForIDComboBox.setItems(registers.getAllUsers());
            }
        } catch (SQLException ignored) {

        }
    }


    public static String getUserName(String userID) {
        try {
            String UserName = "";
            String usernameSQL = "SELECT User_Name FROM users WHERE User_ID =" + userID;
            Connection conn = JDBC.getConnection();
            PreparedStatement usernamepst = conn.prepareStatement(usernameSQL);
            ResultSet usernameWithMatchingUserIDResultSet = usernamepst.executeQuery(usernameSQL);
            while (usernameWithMatchingUserIDResultSet.next()) {
                UserName = usernameWithMatchingUserIDResultSet.getString("User_Name");
            }
            return UserName;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    public static ResultSet giveMeUserInformationForMatchingUsernameAndPassword(String username, String password) throws SQLException {
        Connection conn = JDBC.getConnection();
        DBQuery.setStatement(conn);
        Statement statement = DBQuery.getStatement();
        PreparedStatement loginPST = conn.prepareStatement("SELECT * FROM users WHERE User_Name=? AND Password=? ");//Gives values from users table
        loginPST.setString(1, username);
        loginPST.setString(2, password);
        ResultSet userInformationWithMatchingUsernameAndPasswordResultSet = loginPST.executeQuery();//Get result set
        return userInformationWithMatchingUsernameAndPasswordResultSet;
    }
}
