package helper;

public interface textSetterInterface {
    //Observablelist returning abstract method

    /**
     * This abstract method is used to create a Lambda expression which sets the text for a label
     *
     * @param text the text
     */
    void setText(int text);
}
