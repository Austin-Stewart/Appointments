package helper;

import java.sql.SQLException;

/**
 * This Interface contains the an abstract method which is used to create a greet Lambda expression which greets the user when they login
 */
public interface greeterInterface {
    /**
     * This abstract method is used to create a Lambda expression which greets an individual by their username
     *
     * @param Username the username
     * @return greet(String Username) the greeting
     * @throws SQLException an SQLException
     */
    String greet(String Username) throws SQLException;
}
