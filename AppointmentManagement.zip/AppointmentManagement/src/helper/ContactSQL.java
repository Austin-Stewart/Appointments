package helper;

import javafx.scene.control.ComboBox;
import model.Contact;
import model.appointment;
import model.registers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContactSQL {
    /**
     * This method loads all of the contacts into the desired combo box.
     *
     * @param contactComboBox the desired ComboBox to load
     */
    public static void loadContacts(ComboBox<Contact> contactComboBox) {
        registers.getAllContacts().clear();
        try {
            String sql = "SELECT * FROM Contacts";
            Connection conn = JDBC.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet allInformationFromContactsResultSet = pst.executeQuery(sql);
            while (allInformationFromContactsResultSet.next()) {
                registers.addContact(new Contact(allInformationFromContactsResultSet.getInt("Contact_ID"), allInformationFromContactsResultSet.getString("Contact_Name"), allInformationFromContactsResultSet.getString("Email")));
                contactComboBox.setItems(registers.getAllContacts());
            }
        } catch (SQLException ignored) {

        }
    }

    /**
     * This method returns all of the desired information for a contact from the contacts area in the database based on a contactID.
     *
     * @param apt the appointment which has the desired contactID
     * @return contactpst.executeQuery(contact) the resultset with the desired contact information
     * @throws SQLException SQLException
     */
    public static ResultSet loadContactsInformationBasedOnID(appointment apt) throws SQLException {
        Connection contactConn = JDBC.getConnection();
        String contact = "SELECT * FROM contacts WHERE Contact_ID = " + apt.getContactID();
        PreparedStatement contactpst = contactConn.prepareStatement(contact);
        return contactpst.executeQuery(contact);
    }

}
