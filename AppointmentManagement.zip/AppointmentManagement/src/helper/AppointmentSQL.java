package helper;

import javafx.scene.control.*;
import model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;

public class AppointmentSQL {
    /**
     * This method allows to obtain a result set with the information from the appointments area of the database.
     *
     * @return appointmentInformationPst.executeQuery(appointmentsForTimes) the result set with the appointments information
     * @throws SQLException an SQLException
     */

    public static ResultSet giveMeAppointmentInformation() throws SQLException {
        String appointmentsFromDateBase = "SELECT * FROM appointments";
        //Connects one to the list
        Connection connection = JDBC.getConnection();
        //Created an object which can be sent to the database
        PreparedStatement appointmentInformationPst = connection.prepareStatement(appointmentsFromDateBase);
        //A list returned from the database via the select statement
        return appointmentInformationPst.executeQuery(appointmentsFromDateBase);
    }

    public static ResultSet giveMeAppointmentsWithGivenMonth(ComboBox monthSelectionBox) throws SQLException {
        registers.getAllappointments().clear();
        //Adds local times to the available times list
        Connection conn = JDBC.getConnection();
        String query = "SELECT * FROM java_project.appointments WHERE monthname(Start)=+" + "'" + monthSelectionBox.getSelectionModel().getSelectedItem() + "'";
        PreparedStatement prep = conn.prepareStatement(query);
        ResultSet appointmentsByMonthResultSet = prep.executeQuery();
        return appointmentsByMonthResultSet;
    }

    public static ResultSet givemeAppointmentsWithMacthingContactID(ComboBox<Contact> selectContactForSchedule) throws SQLException {
        registers.getAllAppointments().clear();
        Connection conn = JDBC.getConnection();
        String query = "SELECT * FROM appointments WHERE Contact_ID =" + selectContactForSchedule.getSelectionModel().getSelectedItem().getContact_ID();
        PreparedStatement prep = conn.prepareStatement(query);
        ResultSet appointmentsByContactIDResultSet = prep.executeQuery();
        return appointmentsByContactIDResultSet;
    }

    public static boolean appointmentWithIDExists(int id) throws SQLException {
        Connection appointmentConnection = JDBC.getConnection();
        String appointmentquery = "SELECT * FROM java_project.appointments;";
        PreparedStatement prep;
        prep = appointmentConnection.prepareStatement(appointmentquery);
        ResultSet allAppointmentInformationResultSet = prep.executeQuery();
        while (allAppointmentInformationResultSet.next()) {
            if (allAppointmentInformationResultSet.getInt("Appointment_ID") == id) {
                return true;
            }
        }
        return false;
    }

    public static void updateAppointment(Label modifyOverlapAlert, TextField appointmentIDText, TextField modifyAppointmentTitleText, TextField modifyAppointmentDescriptionText, ComboBox<String> modifyAppointmentLocation, ComboBox<String> modifyAppointmentType, DatePicker modifyAppointmentDate, LocalDateTime selectedStartInUTC, LocalDateTime selectedEndinUTC, ComboBox<customer> selectCustomerID, ComboBox<User> selectUserForIDComboBox, ComboBox<Contact> modifyAppointmentContact) throws SQLException {
        boolean modifyIsBlank = false;
        if (selectUserForIDComboBox.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for UserId");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (selectCustomerID.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value Customer ID");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentLocation.getValue().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Location");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentTitleText.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Title");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentDescriptionText.getText().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for description");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentContact.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Contact");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentType.getValue().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Type");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (modifyAppointmentDate.getValue().toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for the date");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (selectedStartInUTC.toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for Start Time");
            alert.showAndWait();
            modifyIsBlank = true;
        } else if (selectedEndinUTC.toString().isBlank()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Enter a value for End Time");
            alert.showAndWait();
            modifyIsBlank = true;
        }
        if (!modifyIsBlank) {
            Connection conn = JDBC.getConnection();
            Boolean isOverlapping = false;
            LocalDateTime modifyselectedStartinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(modifyAppointmentDate.getValue().getYear(), modifyAppointmentDate.getValue().getMonth(), modifyAppointmentDate.getValue().getDayOfMonth()), LocalTime.of(selectedStartInUTC.getHour(), selectedStartInUTC.getMinute()));
            LocalDateTime modifyselectedEndinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(modifyAppointmentDate.getValue().getYear(), modifyAppointmentDate.getValue().getMonth(), modifyAppointmentDate.getValue().getDayOfMonth()), LocalTime.of(selectedEndinUTC.getHour(), selectedEndinUTC.getMinute()));
            Boolean timeCheck;
            timeCheck = !modifyselectedStartinUTC.isBefore(modifyselectedEndinUTC);
            //The selected time is getting converted to UTC
            System.out.println("Selected Time in UTC" + modifyselectedStartinUTC);
            //Returns the items from the countries list
            String appointmentsForTimes = "SELECT * FROM appointments";
            //Connects one to the list
            Connection connection = JDBC.getConnection();
            //Created an object which can be sent to the database
            PreparedStatement pst = connection.prepareStatement(appointmentsForTimes);
            //A list returned from the database via the select statement
            ResultSet appointmentsForTimesResultSet = pst.executeQuery(appointmentsForTimes);
            while (appointmentsForTimesResultSet.next()) {
                System.out.println("This is the time in UTC" + "|" + dateTimeConnector.dateTime(appointmentsForTimesResultSet.getDate("Start"), appointmentsForTimesResultSet.getTime("Start")));
                if (modifyselectedStartinUTC.isAfter(LocalDateTime.of(appointmentsForTimesResultSet.getDate("Start").toLocalDate(), appointmentsForTimesResultSet.getTime("Start").toLocalTime())) && modifyselectedStartinUTC.isBefore(LocalDateTime.of(appointmentsForTimesResultSet.getDate("End").toLocalDate(), appointmentsForTimesResultSet.getTime("End").toLocalTime())) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(appointmentIDText.getText()))|| selectedEndinUTC.isEqual(LocalDateTime.of(appointmentsForTimesResultSet.getDate("End").toLocalDate(), appointmentsForTimesResultSet.getTime("End").toLocalTime())) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(appointmentIDText.getText())) || modifyselectedStartinUTC.isEqual(LocalDateTime.of(appointmentsForTimesResultSet.getDate("Start").toLocalDate(), appointmentsForTimesResultSet.getTime("Start").toLocalTime())) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(appointmentIDText.getText())) || modifyselectedEndinUTC.isAfter(LocalDateTime.of(appointmentsForTimesResultSet.getDate("Start").toLocalDate(), appointmentsForTimesResultSet.getTime("Start").toLocalTime())) && modifyselectedEndinUTC.isBefore(LocalDateTime.of(appointmentsForTimesResultSet.getDate("End").toLocalDate(), appointmentsForTimesResultSet.getTime("End").toLocalTime()) ) && !AppointmentSQL.appointmentWithIDExists(Integer.parseInt(appointmentIDText.getText()))) {
                    isOverlapping = true;
                    modifyOverlapAlert.setText("This appointment overlaps with another appointment");
                }
            }
            if (isOverlapping.equals(true)) {
                Alert overlapAlert = new Alert(Alert.AlertType.WARNING);
                overlapAlert.setContentText("This appointment overlaps with the following appointment" + "|" + appointmentsForTimesResultSet.getInt("Appointment_ID") + "|" + appointmentsForTimesResultSet.getString("Description"));
                overlapAlert.showAndWait();
            }
            if (timeCheck.equals(true)) {
                Alert incorrectOrderAlert = new Alert(Alert.AlertType.WARNING);
                incorrectOrderAlert.setContentText("The start time must be before the end time");
                incorrectOrderAlert.showAndWait();
            }
            if (isOverlapping.equals(false) && timeCheck.equals(false)) {
                String updateString = " UPDATE appointments SET Appointment_ID = ?, Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Create_Date = ?,Created_By = ?,Last_Update = ?,Last_Updated_By = ?,Customer_ID = ?,User_ID = ?, Contact_ID = ? Where Appointment_ID = ?";
                PreparedStatement update = conn.prepareStatement(updateString);
                update.setInt(1, Integer.parseInt(appointmentIDText.getText()));
                update.setString(2, modifyAppointmentTitleText.getText());
                update.setString(3, modifyAppointmentDescriptionText.getText());
                update.setString(4, modifyAppointmentLocation.getValue());
                update.setString(5, modifyAppointmentType.getValue());
                update.setString(6, selectedStartInUTC.toString());
                update.setString(7, selectedEndinUTC.toString());
                update.setString(8, registers.getCreate_Date());
                update.setString(9, registers.getCreatedBy());
                update.setString(10, timeManagement.giveMeALastUpdate().toString());
                //Gives logged in users ID
                update.setString(11, String.valueOf(registers.getLoggedInUser().getUserName()));
                update.setInt(12, selectCustomerID.getValue().getCustomerID());
                update.setInt(13, selectUserForIDComboBox.getValue().getUser_ID());
                update.setInt(14, modifyAppointmentContact.getValue().getContact_ID());
                update.setString(15, appointmentIDText.getText());
                update.executeUpdate();
            }

        }
    }

    public static void addAppointment(ComboBox<User> addAppointmentUserId, ComboBox<customer> addAppointmentCustomerId, ComboBox<String> appointmentLocationSelector, TextField addAppointmentTitleText, TextField addAppointmentDescriptionText, ComboBox<Contact> addAppointmentContactSelector, ComboBox<String> addAppointmentType, DatePicker addAppointmentDatePicker, ComboBox<LocalTime> addAppointmentStartTimeSelector, ComboBox<LocalTime> addAppointmentEndTimeSelector, Label overlapAlertLbl, TextField addAppointmentIDText) {
        boolean blank = false;
        LocalDateTime createDateInUTCLocalDateTime = timeManagement.giveMeaCreateDate();
        try {
            if (addAppointmentUserId.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for UserId");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentCustomerId.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value Customer ID");
                alert.showAndWait();
                blank = true;
            } else if (appointmentLocationSelector.getValue().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for Location");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentTitleText.getText().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for Title");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentDescriptionText.getText().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for description");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentContactSelector.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for Contact");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentType.getValue().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for Type");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentDatePicker.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for the date");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentStartTimeSelector.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for Start Time");
                alert.showAndWait();
                blank = true;
            } else if (addAppointmentEndTimeSelector.getValue().toString().isBlank()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Enter a value for End Time");
                alert.showAndWait();
                blank = true;
            }
            if (!blank) {
                Connection conn = JDBC.getConnection();
                Boolean isOverlapping = false;
                LocalDateTime selectedStartinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(addAppointmentDatePicker.getValue().getYear(), addAppointmentDatePicker.getValue().getMonth(), addAppointmentDatePicker.getValue().getDayOfMonth()), LocalTime.of(addAppointmentStartTimeSelector.getValue().getHour(), addAppointmentStartTimeSelector.getValue().getMinute()));
                LocalDateTime selectedEndinUTC = timeManagement.giveMeSelectedTimeInUTC(LocalDate.of(addAppointmentDatePicker.getValue().getYear(), addAppointmentDatePicker.getValue().getMonth(), addAppointmentDatePicker.getValue().getDayOfMonth()), LocalTime.of(addAppointmentEndTimeSelector.getValue().getHour(), addAppointmentEndTimeSelector.getValue().getMinute()));
                Boolean timeCheck;
                timeCheck = !selectedStartinUTC.isBefore(selectedEndinUTC);
                //The selected time is getting converted to UTC
                System.out.println("Selected Time in UTC" + selectedStartinUTC);
                //Returns the items from the countries list
                String appointmentsForTimes = "SELECT * FROM appointments";
                //Connects one to the list
                Connection connection = JDBC.getConnection();
                //Created an object which can be sent to the database
                PreparedStatement pst = connection.prepareStatement(appointmentsForTimes);
                //A list returned from the database via the select statement
                ResultSet rs = pst.executeQuery(appointmentsForTimes);
                while (rs.next()) {
                    System.out.println("This is the time in UTC" + "|" + dateTimeConnector.dateTime(rs.getDate("Start"), rs.getTime("Start")));
                    if (selectedStartinUTC.isAfter(LocalDateTime.of(rs.getDate("Start").toLocalDate(), rs.getTime("Start").toLocalTime())) && selectedStartinUTC.isBefore(LocalDateTime.of(rs.getDate("End").toLocalDate(), rs.getTime("End").toLocalTime())) || selectedEndinUTC.isEqual(LocalDateTime.of(rs.getDate("End").toLocalDate(), rs.getTime("End").toLocalTime())) || selectedStartinUTC.isEqual(LocalDateTime.of(rs.getDate("Start").toLocalDate(), rs.getTime("Start").toLocalTime())) || selectedEndinUTC.isAfter(dateTimeConnector.dateTime(rs.getDate("Start"), rs.getTime("Start"))) && selectedEndinUTC.isBefore(dateTimeConnector.dateTime(rs.getDate("End"), rs.getTime("End")))) {
                        isOverlapping = true;
                        overlapAlertLbl.setText("This appointment overlaps with another.");
                    }
                }
                if (isOverlapping) {
                    Alert overlapAlert = new Alert(Alert.AlertType.WARNING);
                    overlapAlert.setContentText("This appointment overlaps with the following appointment" + "|" + rs.getInt("Appointment_ID") + "|" + rs.getString("Description"));
                    overlapAlert.showAndWait();
                }
                if (timeCheck.equals(true)) {
                    Alert incorrectOrderAlert = new Alert(Alert.AlertType.WARNING);
                    incorrectOrderAlert.setContentText("The start time must be before the end time");
                    incorrectOrderAlert.showAndWait();
                }
                // create a sql date object so we can use it in our INSERT statement
                if (isOverlapping.equals(false) && timeCheck.equals(false)) {
                    registers.setCanAddAppointment(true);
                    appointment apt = new appointment(Integer.parseInt(addAppointmentIDText.getText()), addAppointmentTitleText.getText(), addAppointmentDescriptionText.getText(), appointmentLocationSelector.getValue(), addAppointmentType.getValue(), LocalDateTime.parse(addAppointmentDatePicker.getValue() + "T" + addAppointmentStartTimeSelector.getValue()), LocalDateTime.parse(addAppointmentDatePicker.getValue() + "T" + addAppointmentEndTimeSelector.getValue()), Integer.parseInt(addAppointmentCustomerId.getValue().toString()), addAppointmentUserId.getValue().getUser_ID(), addAppointmentContactSelector.getSelectionModel().getSelectedItem().getContact_ID());
                    registers.addappointment(apt);

                    // the mysql insert statement
                    String query = " insert into appointments (Appointment_ID, Title, Description, Location, Type, Start ,End,Create_Date,Created_By,Last_Update,Last_Updated_By,Customer_ID,User_ID,Contact_ID)"
                            + " values (NULL,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                    // create the mysql insert preparedstatement
                    PreparedStatement preparedStmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
                    preparedStmt.setString(1, addAppointmentTitleText.getText());
                    preparedStmt.setString(2, addAppointmentDescriptionText.getText());
                    preparedStmt.setString(3, appointmentLocationSelector.getValue());
                    preparedStmt.setString(4, addAppointmentType.getValue());
                    //This converts the appointment times to UTC before storing and then stores them
                    preparedStmt.setString(5, String.valueOf(selectedStartinUTC));
                    preparedStmt.setString(6, String.valueOf(selectedEndinUTC));
                    preparedStmt.setString(7, String.valueOf(timeManagement.giveMeaCreateDate()));
                    preparedStmt.setString(8, registers.getLoggedInUser().getUserName());
                    preparedStmt.setString(9, String.valueOf(timeManagement.giveMeALastUpdate()));
                    preparedStmt.setString(10, registers.getLoggedInUser().getUserName());
                    preparedStmt.setInt(11, Integer.parseInt(addAppointmentCustomerId.getValue().toString()));
                    preparedStmt.setInt(12, addAppointmentUserId.getValue().getUser_ID());
                    preparedStmt.setInt(13, addAppointmentContactSelector.getSelectionModel().getSelectedItem().getContact_ID());
                    // execute the preparedstatement
                    preparedStmt.execute();

                }

            }
        } catch (NoSuchElementException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty List");
            alert.setContentText("The list is empty quit trying to delete things.");
            alert.showAndWait();
        } catch (NullPointerException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Empty field");
            alert.setContentText("Please enter a value for all fields.");
            alert.showAndWait();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void deleteAppointment(appointment apt) throws SQLException {
        Connection conn = JDBC.getConnection();
        String deleteAppointmentsWithMatchingID = " DELETE FROM appointments WHERE Appointment_ID =" + apt.getAppointmentID();
        PreparedStatement prepDeleteAppointment = conn.prepareStatement(deleteAppointmentsWithMatchingID);
        prepDeleteAppointment.execute();
    }

    public static ResultSet giveMeAppointmentsByLocation(ComboBox<String> SelectLocationForAppointmentsComboBox) throws SQLException {
        registers.getAllAppointments().clear();
        Connection conn = JDBC.getConnection();
        String query = "SELECT * FROM appointments WHERE Location =" + "'" + SelectLocationForAppointmentsComboBox.getSelectionModel().getSelectedItem() + "'";
        PreparedStatement prep = conn.prepareStatement(query);
        ResultSet appointmentsByLocationResultSet = prep.executeQuery();
        return appointmentsByLocationResultSet;
    }

    public static ResultSet giveMeAppointmentsWithMatchingIDs(appointment appointment) throws SQLException {
        Connection conn = JDBC.getConnection();
        appointment apt = appointment;
        String appointmentSQL = "SELECT * FROM appointments Where Appointment_ID = " + apt.getAppointmentID();
        PreparedStatement prep = conn.prepareStatement(appointmentSQL);
        ResultSet appointmentRs = prep.executeQuery();
        return appointmentRs;
    }

    public static ResultSet giveMeMonthlyAppointments() throws SQLException {
        registers.getAllMonthlyAppointments().clear();
        Connection conn = JDBC.getConnection();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        String appointmentSQL = "SELECT * FROM appointments WHERE MONTH(CURRENT_DATE())";
        PreparedStatement prep = conn.prepareStatement(appointmentSQL);
        ResultSet appointmentRs = prep.executeQuery();
        return appointmentRs;
    }

    public static ResultSet giveMeWeeklyAppointments() throws SQLException {
//        Connection conn = JDBC.getConnection();
//        registers.getAllWeeklyAppointments().clear();
//        LocalDate today = LocalDate.now();
//        System.out.println(today.getDayOfWeek());
//        if(today.getDayOfWeek().toString().equals("SUNDAY")){
//            String query = "SELECT * FROM appointments WHERE DAY(Start) BETWEEN DAY( CURRENT_DATE() - (SELECT DAYOFWEEK(CURRENT_DATE())-1)) AND DAY((CURRENT_DATE()+(7 - (SELECT DAYOFWEEK(CURRENT_DATE())) ) )) AND MONTH(Start)=MONTH(CURRENT_DATE()) ";
//            PreparedStatement prep = conn.prepareStatement(query);
//            ResultSet appointmentRs = prep.executeQuery();
//            return appointmentRs;
//        }
//        else if (!today.getDayOfWeek().toString().equals("SUNDAY")){
//            String query = "SELECT * FROM appointments WHERE DAY(Start) BETWEEN DAY( CURRENT_DATE()) AND DAY((CURRENT_DATE()+(7)) AND MONTH(Start)=MONTH(CURRENT_DATE()) ";
//            PreparedStatement prep = conn.prepareStatement(query);
//            ResultSet appointmentRs = prep.executeQuery();
//            return appointmentRs;
//        }
//        return null;
        return null;
    }
}