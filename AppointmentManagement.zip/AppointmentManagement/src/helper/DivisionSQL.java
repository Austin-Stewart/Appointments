package helper;

import javafx.scene.control.ComboBox;
import model.Country;
import model.Division;
import model.customer;
import model.registers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DivisionSQL {
    /**
     * This method loads the division information into a desired ComboBox.
     *
     * @param CountryComboBox         the country selected
     * @param StateOrProvinceComboBox the combobox with the associated divisions in it
     * @throws SQLException an SQLException
     */
    public static void loadDivisionInformation(ComboBox<Country> CountryComboBox, ComboBox<Division> StateOrProvinceComboBox) throws SQLException {
        Country country = CountryComboBox.getSelectionModel().getSelectedItem();
        if (country == null) {
        } else {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = " + country.getId();
            Connection conn = JDBC.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery(sql);
            registers.getAllDivisions().clear();
            while (rs.next()) {
                registers.addDivision(new Division(rs.getInt("Division_ID"), rs.getString("Division"), rs.getInt("Country_ID")));
                StateOrProvinceComboBox.setItems(registers.getAllDivisions());

            }
        }

    }

    /**
     * This method gives allows one to get information from the countries table and the first_level_divisions table where the DivisionID matches
     *
     * @param DivisionID the division ID
     * @return pst.executeQuery(sql) the resultset which contains the country and division data where the DivisionID matches
     * @throws SQLException an SQLException
     */
    public static ResultSet giveMeMatchingCountryAndDivisionInformation(int DivisionID) throws SQLException {
        String sql = "SELECT * FROM first_level_divisions,Countries WHERE Division_ID =" + DivisionID;
        Connection conn = JDBC.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql);
        return pst.executeQuery(sql);
    }

    /**
     * This method gives allows one to obtain a country ID from a division ID
     *
     * @param customer the customer who has the Division ID to be used
     * @return countryIDpst.executeQuery(countryIDSQL) the resultset which the country id that one wants to obtain
     * @throws SQLException an SQLException
     */
    public static ResultSet giveMeMatchingCountryIDFromDivisionID(customer customer) throws SQLException {
        Connection connection = JDBC.getConnection();
        String countryIDSQL = "SELECT COUNTRY_ID FROM first_level_divisions WHERE Division_ID =" + customer.getDivisionID();
        PreparedStatement countryIDpst = connection.prepareStatement(countryIDSQL);
        return countryIDpst.executeQuery(countryIDSQL);
    }
}
