package helper;

import model.appointment;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * This class contains method which allow one to combine dates and times into Local date times and to extract dates and times from strings
 */
public class dateTimeConnector {
    /**
     * This method allows one to connect a date and a time into a LocalDateTime.
     *
     * @param date the Date
     * @param time the Time
     * @return dateTime The LocalDateTime
     */
    public static LocalDateTime dateTime(Date date, Time time) {
        String dT = date + " " + time;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime dateTime = LocalDateTime.parse(dT, formatter);
        return (dateTime);
    }

    /**
     * This method allows one to extract the start date from an appointment object.
     *
     * @param apt the appointment
     * @return LocalDate.parse(Date, dtf) the Local date of the appointment
     */
    public static LocalDate StartDateExtractor(appointment apt) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.getDefault());
        String start = String.valueOf(apt.getStartTime());
        int TCount = 0;
        StringBuilder Date = new StringBuilder();
        char[] ch = start.toCharArray();
        for (int i = 0; i < start.indexOf("T"); i++) {
            Date.append(ch[i]);
        }
        return LocalDate.parse(Date.toString(), dtf);
    }

    /**
     * This method allows one to extract the start time from an appointment object.
     *
     * @param apt the appointment
     * @return LocalTime.parse(Time, dtf) the Local time of the appointment
     */
    public static LocalTime StartTimeExtractor(appointment apt) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault());
        String start = String.valueOf(apt.getStartTime());
        int TCount = 0;
        StringBuilder Time = new StringBuilder();
        char[] ch = start.toCharArray();
        for (int i = 0; i < start.length(); i++) {
            if (i > start.indexOf("T"))
                Time.append(ch[i]);
        }
        return LocalTime.parse(Time.toString(), dtf);
    }

    /**
     * This method allows one to extract the end date from an appointment object.
     *
     * @param apt the appointment
     * @return LocalDate.parse(Date, dtf) the Local date of the appointment
     */
    public static LocalDate EndDateExtractor(appointment apt) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.getDefault());
        String start = String.valueOf(apt.getEndTime());
        int TCount = 0;
        StringBuilder Date = new StringBuilder();
        char[] ch = start.toCharArray();
        for (int i = 0; i < start.indexOf("T"); i++) {
            Date.append(ch[i]);
        }
        return LocalDate.parse(Date.toString(), dtf);
    }

    /**
     * This method allows one to extract the end time from an appointment object.
     *
     * @param apt the appointment
     * @return LocalTime.parse(Time, dtf) the Local time of the appointment
     */
    public static LocalTime EndTimeExtractor(appointment apt) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault());
        String start = String.valueOf(apt.getEndTime());
        int TCount = 0;
        StringBuilder Time = new StringBuilder();
        char[] ch = start.toCharArray();
        for (int i = 0; i < start.length(); i++) {
            if (i > start.indexOf("T"))
                Time.append(ch[i]);
        }
        return LocalTime.parse(Time.toString(), dtf);
    }


}


