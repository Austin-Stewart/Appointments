package helper;

import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import model.registers;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;

/**
 * This class has methods used to convert between time zones and test if an appointment is going to occur within 15 minutes
 */
public class timeManagement {

    /**
     * This method returns the time difference in hours between EST and the time zone set on a computer
     *
     * @return timeDifferenceInHours the time difference in hours between EST and the time zone set on a computer
     */
    public static long ESTToLocal() {
        TimeZone EST = TimeZone.getTimeZone("EST");
        TimeZone computerTime = TimeZone.getTimeZone(ZoneId.systemDefault());
        long timeDifferenceInHours = (EST.getRawOffset() - computerTime.getRawOffset()) / 3600000;
        return timeDifferenceInHours;
    }

    public static LocalDateTime giveMeaCreateDate() {
        LocalDate nowdate = LocalDate.now();
        LocalTime createTime = LocalTime.of(LocalTime.now().getHour(), LocalTime.now().getMinute());
        LocalDateTime myCreateDateLDT = LocalDateTime.of(nowdate, createTime);
        ZoneId myZoneForCreateID = ZoneId.systemDefault();
        ZoneId UTC = ZoneId.of("UTC");
        ZonedDateTime myCreateZDT = ZonedDateTime.of(myCreateDateLDT, myZoneForCreateID);
        ZonedDateTime createDateInUTC = ZonedDateTime.ofInstant(myCreateZDT.toInstant(), UTC);
        return createDateInUTC.toLocalDateTime();
    }

    public static LocalDateTime giveMeALastUpdate() {
        LocalDate updateDate = LocalDate.now();
        LocalTime updateTime = LocalTime.of(LocalTime.now().getHour(), LocalTime.now().getMinute());
        LocalDateTime myCreateDateLDT = LocalDateTime.of(updateDate, updateTime);
        ZoneId myZoneForCreateID = ZoneId.systemDefault();
        ZoneId UTC = ZoneId.of("UTC");
        ZonedDateTime myUpdateZDT = ZonedDateTime.of(myCreateDateLDT, myZoneForCreateID);
        ZonedDateTime LastUpdateDateInUTC = ZonedDateTime.ofInstant(myUpdateZDT.toInstant(), UTC);
        return LastUpdateDateInUTC.toLocalDateTime();
    }

    public static ZoneId giveMeUTCZoneID() {
        return ZoneId.of("UTC");
    }

    /**
     * This method loads the start and end times into desired ComboBoxes.
     *
     * @param appointmentStartTimes the desired starttime ComboBox to fill
     * @param appointmentEndTimes   the desired endtime ComboBox to fill
     */
    public static void fillTimeLists(ComboBox<LocalTime> appointmentStartTimes, ComboBox<LocalTime> appointmentEndTimes) {
        DateTimeFormatter timeDTF = DateTimeFormatter.ofPattern("HH:mm:ss");//ISO standard time format
        registers.getAllEndTimes().clear();
        registers.getAllStartTimes().clear();
        long estToLocal = timeManagement.ESTToLocal();
        LocalTime time = LocalTime.of(8, 0, 0).minusHours(estToLocal);
        while (!time.equals(LocalTime.of(22, 20, 0).minusHours(estToLocal))) {
            registers.getAllStartTimes().add(LocalTime.parse(time.format(timeDTF)));
            registers.getAllEndTimes().add(LocalTime.parse(time.format(timeDTF)));
            time = time.plusMinutes(20);
        }
        appointmentStartTimes.setItems(registers.getAllStartTimes());
        appointmentEndTimes.setItems(registers.getAllEndTimes());
    }
    /**
     * This method returns the time entered in the Localtimezone in UTC
     * @param modifyAppointmentDate the LocalDate
     * @param modifyAppointmentTime the LocalTime
     * @return ZDTInUTC.toLocalDateTime() the Local time in UTC
     */
    public static LocalDateTime giveMeSelectedTimeInUTC(LocalDate modifyAppointmentDate, LocalTime modifyAppointmentTime) {
        ZoneId UTC = timeManagement.giveMeUTCZoneID();
        LocalDate date = LocalDate.of(modifyAppointmentDate.getYear(), modifyAppointmentDate.getMonth(), modifyAppointmentDate.getDayOfMonth());
        LocalTime Time = LocalTime.of(modifyAppointmentTime.getHour(), modifyAppointmentTime.getMinute());
        LocalDateTime LDT = LocalDateTime.of(date, Time);
        ZoneId myZoneID = ZoneId.systemDefault();
        ZonedDateTime ZDT = ZonedDateTime.of(LDT, myZoneID);
        ZonedDateTime ZDTInUTC = ZonedDateTime.ofInstant(ZDT.toInstant(), UTC);
        return ZDTInUTC.toLocalDateTime();
    }
    /**
     * This method returns the time entered in the UTC in Localtime
     * @param modifyAppointmentDate the LocalDate
     * @param modifyAppointmentTime the LocalTime
     * @return zonedDateTimeLocal.toLocalDateTime() the UTC time in LocalTime
     */
    public static LocalDateTime giveMeSelectedTimeInLocal(LocalDate modifyAppointmentDate, LocalTime modifyAppointmentTime) {
        ZoneId UTC = timeManagement.giveMeUTCZoneID();
        LocalDate date = LocalDate.of(modifyAppointmentDate.getYear(), modifyAppointmentDate.getMonth(), modifyAppointmentDate.getDayOfMonth());
        LocalTime time = LocalTime.of(modifyAppointmentTime.getHour(), modifyAppointmentTime.getMinute());
        LocalDateTime LDT = LocalDateTime.of(date, time);
        ZoneId myZoneID = ZoneId.systemDefault();
        ZonedDateTime UTCZDT = ZonedDateTime.of(LDT, UTC);
        ZonedDateTime zonedDateTimeLocal = ZonedDateTime.ofInstant(UTCZDT.toInstant(), myZoneID);
        return zonedDateTimeLocal.toLocalDateTime();
    }

    /**
     * This method returns the a boolean which tells someone if a appointment is occuring within 15 minutes
     * @throws SQLException an SQLException
     * @return isWithinFifteen the boolean the shows if an appointment is going to occur within 15 minutes
     */
    public static Boolean isWithin15Mins() throws SQLException {
        boolean isWithinFifteen = false;
        Connection loginConnection = JDBC.getConnection();
        LocalDate nowDate = LocalDate.now();
        LocalTime nowTime = LocalTime.now();
        LocalDateTime currentDateTime = LocalDateTime.of(nowDate, nowTime);
        ResultSet allAppointmentInformationResultSet = AppointmentSQL.giveMeAppointmentInformation();
        while (allAppointmentInformationResultSet.next()) {
            System.out.println(timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()));
            System.out.println("This is the current time in Local" + currentDateTime);
            if (timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isAfter(currentDateTime) && timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isBefore(currentDateTime.plusMinutes(15)) || timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isEqual(currentDateTime) || timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isEqual(currentDateTime.plusMinutes(15))) {
                Alert fifteenMinCheck = new Alert(Alert.AlertType.WARNING);
                fifteenMinCheck.setContentText("You have  the following appointment within the next 15 mins" + "Appointment ID: " + allAppointmentInformationResultSet.getInt("Appointment_ID") + "Date and Time: " + timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()));
                fifteenMinCheck.showAndWait();
                isWithinFifteen = true;
                return isWithinFifteen;
            }
        }
        isWithinFifteen = false;
        return isWithinFifteen;
    }

    /**
     * This method returns the a boolean which tells someone if a appointment is occuring within 15 minutes
     * @throws SQLException an SQLException
     * @return isWithinFifteen the boolean the shows if an appointment is going to occur within 15 minutes
     */
    public static Boolean isWithin15Minsfr() throws SQLException {
        boolean isWithinFifteen = false;
        Connection loginConnection = JDBC.getConnection();
        LocalDate nowDate = LocalDate.now();
        LocalTime nowTime = LocalTime.now();
        LocalDateTime currentDateTime = LocalDateTime.of(nowDate, nowTime);
        ResultSet allAppointmentInformationResultSet = AppointmentSQL.giveMeAppointmentInformation();
        while (allAppointmentInformationResultSet.next()) {
            if (timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isAfter(currentDateTime) && timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isBefore(currentDateTime.plusMinutes(15)) || timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isEqual(currentDateTime) || timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()).isEqual(currentDateTime.plusMinutes(15))) {
                Alert fifteenMinCheck = new Alert(Alert.AlertType.WARNING);
                fifteenMinCheck.setContentText("Vous avez le prochain rendez-vous dans les 15 prochaines minutes" + "Identifiant de rendez-vous: " + allAppointmentInformationResultSet.getInt("Appointment_ID") + "Date et l'heure: " + timeManagement.giveMeSelectedTimeInLocal(allAppointmentInformationResultSet.getDate("Start").toLocalDate(), allAppointmentInformationResultSet.getTime("Start").toLocalTime()));
                fifteenMinCheck.showAndWait();
                isWithinFifteen = true;
                return isWithinFifteen;
            }
        }
        isWithinFifteen = false;
        return isWithinFifteen;
    }
}

