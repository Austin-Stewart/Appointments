
# Customer Appointment Scheduling Application

The purpose of this application is to allow a user to add keep track of their users and the appointments associated with them.


## Authors

- [@AustinStewart](https://github.com/aste467)
The author of this application is Austin Stewart.

## Contact Information
Email: aste467@wgu.edu
Phone: 406-439-3362

## IDE And version Number
IDE and Version Number: IntelliJ Community 2020.1.3
## JDK And JFX Version
JDK version:  Java SE 11.0.13
JFX Version: javafx-sdk-17.0.1

## Directions For How To Run The Program
In order to run this program open the files in the IntelliJ IDE and then configure the path variables and other things properly, then press the Run button in the IDE and it should open up.

## Description Of The Additional Report Of My Choice That I Ran In Part A3f
The additional report that I created was based on a business need for my business, which was to show the appointments that occur at the common locations at which my business and employees operate. One can choose one of the locations where my business's clients commonly want to meet for appointments, and the report will display all of the appointments which occur at that location in a table view.
