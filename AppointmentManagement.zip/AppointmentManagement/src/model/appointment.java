package model;

import java.time.LocalDateTime;

/**
 * This class allows one to create appointments.
 */
public class appointment {
    private final int appointmentID;
    private final String Title;
    private final String Description;
    private final String Location;
    private final String Type;
    private final LocalDateTime startTime;
    private final LocalDateTime endTime;
    private final int customerID;
    private final int userID;
    private final int contactID;

    /**
     * This is the constructor method for appointments.
     *
     * @param appointmentID the appointmentID
     * @param Title         the appointment title
     * @param Description   A description for the appointment
     * @param Location      the location for the appointment
     * @param Type          the type of appointment
     * @param startTime     the appointments start time
     * @param endTime       the appointments end time
     * @param customerID    the appointments customerID
     * @param userID        the appointments usedID
     * @param contactID     the appointments contactID
     */
    public appointment(int appointmentID, String Title, String Description, String Location, String Type, LocalDateTime startTime, LocalDateTime endTime, int customerID, int userID, int contactID) {
        this.appointmentID = appointmentID;
        this.Title = Title;
        this.Description = Description;
        this.Location = Location;
        this.Type = Type;
        this.startTime = startTime;
        this.endTime = endTime;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }




    /**
     * This method allows one to get the Appointment id for an appointment.
     *
     * @return Appointment_ID the Appointment id for the appointment
     */
    public int getAppointmentID() {
        return appointmentID;
    }

    /**
     * This method allows one to get the title for an appointment.
     *
     * @return Title the title for an appointment
     */
    public String getTitle() {
        return Title;
    }

    /**
     * This method allows one to get the description for an appointment.
     *
     * @return Description the description for the appointment
     */
    public String getDescription() {
        return Description;
    }

    /**
     * This method allows one to get the location for an appointment.
     *
     * @return Location the location for the appointment
     */
    public String getLocation() {
        return Location;
    }

    /**
     * This method allows one to get type of an appointment.
     *
     * @return Type the type of an appointment
     */
    public String getType() {
        return Type;
    }

    /**
     * This method allows one to get the start time for an appointment.
     *
     * @return startTime the start time for an appointment
     */
    public LocalDateTime getStartTime() {

        return startTime;
    }

    /**
     * This method allows one to get the end time for an appointment.
     *
     * @return endTime the end time for an appointment
     */
    public LocalDateTime getEndTime() {
        return endTime;
    }

    /**
     * This method allows one to get the customer id for an appointment.
     *
     * @return customerID the customer id
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * This method allows one to get the user id for an appointment.
     *
     * @return User_ID the user id for the appointment
     */
    public int getUserID() {
        return userID;
    }

    /**
     * This method allows one to get the contact id for an appointment.
     *
     * @return Contact_ID the contact id for the appointment
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * This method overrides an appointments toString() method.
     *
     * @return appointmentID the appointment id
     * @return Title the appointment title
     * @return Description the appointment description
     * @return Location the appointment location
     * @return Type the appointment type
     * @return startTime the appointment start time
     * @return endTime the appointment end time
     * @return customerID the appointment customer id
     * @return userID the appointment user id
     * @return contactID the appointment contact id;
     */
    public String toString() {
        return appointmentID + Title + Description + Location + Type + startTime + endTime + customerID + userID + contactID;
    }
}