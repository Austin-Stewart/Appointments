package model;

/**
 * This class allows one to create User objects.
 */
public class User {
    private final int userID;
    private final String userName;

    /**
     * This is a constructor method for User objects.
     *
     * @param userID   the user id
     * @param userName the username
     * @param Password the password
     */
    public User(int userID, String userName, String Password) {
        this.userID = userID;
        this.userName = userName;
    }

    /**
     * This is a constructor method for User objects.
     *
     * @param user_ID   the user id
     * @param User_Name the User_Name
     */
    public User(String User_Name, int user_ID) {
        this.userID = user_ID;
        this.userName = User_Name;
    }

    /**
     * This method allows one to get the User_ID id.
     *
     * @return User_ID for a User object
     */
    public int getUser_ID() {
        return userID;
    }

    /**
     * This method allows one to get the User_Name for a User object.
     *
     * @return User_Name the username for a User object
     */
    public String getUserName() {
        return userName;
    }

    @Override
    public String toString() {
        return userName + "|" + userID;
    }

}

