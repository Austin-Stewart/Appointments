package model;

/**
 * This class allows one to create Country objects.
 */
public class Country {
    private final int id;
    private final String country;

    /**
     * This is the constructor method for Country objects.
     *
     * @param id      the Country id
     * @param country the country name
     */
    public Country(int id, String country) {
        this.id = id;
        this.country = country;
    }

    /**
     * This method allows one to get the country id.
     *
     * @return id the country id
     */
    public int getId() {
        return id;
    }

    /**
     * This method allows one to get the country name.
     *
     * @return country the country name
     */
    public String getCountry() {
        return country;
    }

    @Override
    public String toString() {
        return country;
    }
}
