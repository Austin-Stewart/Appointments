package model;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;

/**
 * This class allows one to add, and delete objects from the appropriate lists.
 */
public class registers {
    private static final ObservableList<Integer> allCustomerIDs = FXCollections.observableArrayList();
    private static final ObservableList<Country> allCountries = FXCollections.observableArrayList();
    private static final ObservableList<customer> allcustomers = FXCollections.observableArrayList();
    private static final ObservableList<User> allUsers = FXCollections.observableArrayList();
    private static final ObservableList<String> allMonths =
            FXCollections.observableArrayList(
                    "JANUARY",
                    "FEBRUARY",
                    "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"
            );
    private static final ObservableList<String> allLocations =
            FXCollections.observableArrayList(
                    "Firetower",
                    "Library",
                    "Front Office", "Lobby", "Home", "Customers Home"
            );
    private static final ObservableList<appointment> allAppointments = FXCollections.observableArrayList();
    private static final ObservableList<Division> allDivisions = FXCollections.observableArrayList();
    private static final ObservableList<Contact> allContacts = FXCollections.observableArrayList();
    private static final ObservableList<Integer> customerIDs = FXCollections.observableArrayList();
    private static final ObservableList<Integer> appointmentIDs = FXCollections.observableArrayList();
    private static final ObservableList<String> appointmentTypes = FXCollections.observableArrayList();
    private static final ObservableList<LocalTime> allStartTimes = FXCollections.observableArrayList();
    private static final ObservableList<LocalTime> allEndTimes = FXCollections.observableArrayList();
    private static final ObservableList<appointment> allMonthlyAppointments = FXCollections.observableArrayList();
    private static final ObservableList<String> allAppointmentTypes =
            FXCollections.observableArrayList(
                    "In-Person",
                    "Online",
                    "Telephone", "New Appointment", "Kickoff Meeting", "Closeout Meeting", "Quality Assurance"
            );
    private static final ObservableList<appointment> allWeeklyAppointments = FXCollections.observableArrayList();
    private static User loggedInUser;
    private static String createdBy;
    private static Contact appointmentContact;
    private static String Create_Date;
    private static boolean canAddAppointment = false;
    private static boolean isWithinFifteenMinutes = false;

    public static boolean isIsWithinFifteenMinutes() {
        return isWithinFifteenMinutes;
    }

    public static void setIsWithinFifteenMinutes(boolean isWithinFifteenMinutes) {
        registers.isWithinFifteenMinutes = isWithinFifteenMinutes;
    }

    /**
     * This method allows one to get the value for the canAddAppointment boolean which is used to decide when one can add an appointment.
     *
     * @return canAddAppointment a boolean used to tell the program when it can add an appointment
     */
    public static boolean isCanAddAppointment() {
        return canAddAppointment;
    }

    /**
     * This method allows one to set the boolean value for the canAddAppointment boolean.
     *
     * @param canAddAppointment the boolean value that is being set
     */
    public static void setCanAddAppointment(boolean canAddAppointment) {
        registers.canAddAppointment = canAddAppointment;
    }

    /**
     * This method allows one to get the list of weekly appointments in the allWeeklyAppointments list.
     *
     * @return allWeeklyAppointments the list of weekly appointments
     */
    public static ObservableList<appointment> getAllWeeklyAppointments() {
        return allWeeklyAppointments;
    }


    /**
     * This method allows one to get the list of locations in the allLocations list.
     *
     * @return allLocations the list of locations
     */
    public static ObservableList<String> getAllLocations() {
        return allLocations;
    }

    /**
     * This method allows one to get the list of all appointment types in the allAppointmentTypes list.
     *
     * @return allAppointmentTypes the list of appointment types
     */
    public static ObservableList<String> getAllAppointmentTypes() {
        return allAppointmentTypes;
    }


    /**
     * This method allows one to get the list of all the months in a year in the allMonths list.
     *
     * @return allMonths the list of every month in a year
     */
    public static ObservableList<String> getAllMonths() {
        return allMonths;
    }

    /**
     * This method returns the list all the monthly appointments in a year in the allMonthlyAppointments list.
     *
     * @return allMonthlyAppointments the list appointments occurring within a month
     */
    public static ObservableList<appointment> getAllMonthlyAppointments() {
        return allMonthlyAppointments;
    }


    /**
     * This method allows one to get the create date of an object.
     *
     * @return Create_Date the create date for an object
     */
    public static String getCreate_Date() {
        return Create_Date;
    }

    /**
     * This method allows one to set the value for the create date.
     *
     * @param create_Date the create date for an object
     */
    public static void setCreate_Date(String create_Date) {
        Create_Date = create_Date;
    }

    /**
     * This method allows one to get the allowed start times for an appointment.
     *
     * @return allStartTimes the list of all of the start times possible for an appointment
     */
    public static ObservableList<LocalTime> getAllStartTimes() {
        return allStartTimes;
    }

    /**
     * This method allows one to get the allowed end times for an appointment.
     *
     * @return allEndTimes the list of all of the end times possible for an appointment
     */
    public static ObservableList<LocalTime> getAllEndTimes() {
        return allEndTimes;
    }

    /**
     * This method allows one to get the list of all the divisions from the allDivisions list.
     *
     * @return allDivisions the list of all the divisions
     */
    public static ObservableList<Division> getAllDivisions() {
        return allDivisions;
    }

    /**
     * This method allows one to get the list of all the contacts from the allContacts list.
     *
     * @return allContacts the list of all the contacts
     */
    public static ObservableList<Contact> getAllContacts() {
        return allContacts;
    }

    /**
     * This method allows one to get the list of all the users from the allUsers list.
     *
     * @return allUsers the list of all the users
     */
    public static ObservableList<User> getAllUsers() {
        return allUsers;
    }

    /**
     * This method allows one to add a division to the allDivisions list.
     *
     * @param division the division the be added
     */
    public static void addDivision(Division division) {
        allDivisions.add(division);
    }

    /**
     * This method allows one to add a user to the allUsers list.
     *
     * @param user the User the be added
     */
    public static void addUser(User user) {
        allUsers.add(user);
    }

    /**
     * This method allows one to add a contact to the allContacts list.
     *
     * @param contact the Contact the be added
     */
    public static void addContact(Contact contact) {
        allContacts.add(contact);
    }

    /**
     * This method allows one to get the value for which user created a given object.
     *
     * @return createdBy the name of the user who created an object
     */
    public static String getCreatedBy() {
        return createdBy;
    }

    /**
     * This method allows one to set the value for the createdBy variable.
     *
     * @param creator the username for the one who created an object
     */
    public static void setCreatedBy(String creator) {
        createdBy = creator;
    }

    /**
     * This method allows one to get the name of the user who is currently logged in.
     *
     * @return loggedInUser the username of the currently logged in user
     */
    public static User getLoggedInUser() {
        return loggedInUser;
    }

    /**
     * This method allows one to set the value for the loggedInUser variable.
     *
     * @param loggedInUser the current logged in users username
     */
    public static void setLoggedInUser(User loggedInUser) {
        registers.loggedInUser = loggedInUser;
    }

    /**
     * This method allows one to delete a customer from the allcustomers list.
     *
     * @param deleteCust the customer to be deleted
     */
    public static void deleteCustomer(customer deleteCust) {
        allcustomers.remove(deleteCust);
    }

    /**
     * This method allows one to delete an appointment from the allAppointments list.
     *
     * @param deleteapt the appointment to be deleted
     */
    public static void deleteAppointment(appointment deleteapt) {
        allAppointments.remove(deleteapt);
    }

    /**
     * This method allows one to get the list of all the appointments from the allAppointments list.
     *
     * @return allAppointments the list of all appointments
     */
    public static ObservableList<appointment> getAllAppointments() {
        return allAppointments;
    }


    /**
     * This method allows one to get the list of all countries from the allCountries list.
     *
     * @return allCountries the list of all countries
     */
    public static ObservableList<Country> getAllCountries() {
        return allCountries;
    }

    /**
     * This method allows one to add a Country to the allCountries list.
     *
     * @param country    the name of the country to be added
     * @param country_id the id of the country to be added
     */
    public static void addCountry(int country_id, String country) {
        allCountries.add(new Country(country_id, country));
    }

    /**
     * This method allows one to add a customer to the allcustomers list.
     *
     * @param newCustomer the Customer the be added
     */
    public static void addcustomer(customer newCustomer) {
        allcustomers.add(newCustomer);
    }

    /**
     * This method allows one to add an appointment to the allAppointments list.
     *
     * @param newappointment the appointment the be added
     */
    public static void addappointment(appointment newappointment) {
        allAppointments.add(newappointment);
    }


    /**
     * This method allows one to get the list of customers from the allcustomers list.
     *
     * @return allcustomers the list of all customers
     */
    public static ObservableList<customer> getAllcustomers() {
        return allcustomers;
    }

    /**
     * This method allows one to get the list of appointments from the allAppointments list.
     *
     * @return allAppointments the list of all appointments
     */
    public static ObservableList<appointment> getAllappointments() {
        return allAppointments;
    }

    /**
     * This method searches through the database and finds the value of ID which will be set for a customer object once it is created and returns that value.
     *
     * @return id the id which will be created by the database
     * @throws SQLException an SQLException
     */
    public static int givemeaCustomerid() throws SQLException {
        //Generate result set of current customer ID's
        String sql = "SELECT Customer_ID FROM customers";
        //Connects one to the list
        Connection conn = JDBC.getConnection();
        //Created an object which can be sent to the database
        PreparedStatement pst = conn.prepareStatement(sql);
        //A list returned from the database via the select statement
        ResultSet rs = pst.executeQuery(sql);
        while (rs.next()) {
            customerIDs.add(rs.getInt("Customer_ID"));
        }
        int id = 0;
        for (int iD : customerIDs) {
            if (iD >= id) {
                id = iD + 1;
            }
        }
        return id;
    }

    /**
     * This method searches through the database and finds the value of ID which will be set for an appointment object once it is created and returns that value.
     *
     * @return id the id which will be created by the database
     * @throws SQLException an SQLException
     */
    public static int giveMeAnAppointmentId() throws SQLException {
        //Generate result set of current customer ID's
        String sql = "SELECT Appointment_ID FROM appointments";
        //Connects one to the list
        Connection conn = JDBC.getConnection();
        //Created an object which can be sent to the database
        PreparedStatement pst = conn.prepareStatement(sql);
        //A list returned from the database via the select statement
        ResultSet rs = pst.executeQuery(sql);
        while (rs.next()) {
            appointmentIDs.add(rs.getInt("Appointment_ID"));
        }
        int id = 0;
        for (int iD : appointmentIDs) {
            if (iD >= id) {
                id = iD + 1;
            }
        }
        return id;
    }

}
