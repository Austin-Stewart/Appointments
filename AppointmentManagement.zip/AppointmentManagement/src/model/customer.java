package model;

/**
 * This class allows one to create customer objects.
 */
public class customer {
    private final int customerID;
    private String customerName;
    private String Address;
    private String postalCode;
    private String Phone;
    private int divisionID;

    /**
     * This is a constructor method for customer objects.
     *
     * @param customerID   the customer id
     * @param customerName the customer name
     * @param Address      the customers address
     * @param postalCode   the customers postal code
     * @param Phone        the customers phone
     * @param divisionID   the customers division id
     */
    public customer(int customerID, String customerName, String Address, String postalCode, String Phone, int divisionID) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.Address = Address;
        this.postalCode = postalCode;
        this.Phone = Phone;
        this.divisionID = divisionID;


    }

    /**
     * This is a constructor method for customer objects.
     *
     * @param customer_ID the customer id
     */
    public customer(int customer_ID) {
        customerID = customer_ID;
    }

    /**
     * This method allows one to get the customer id.
     *
     * @return Customer_ID the customer id
     */
    public int getCustomerID() {
        return customerID;
    }

    /**
     * This method allows one to get the customer name.
     *
     * @return Customer_Name the customer name
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * This method allows one to get the customers address.
     *
     * @return Address the customers address
     */
    public String getAddress() {
        return Address;
    }

    /**
     * This method allows one to get the customer postal code.
     *
     * @return Postal_Code the customers postal code
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * This method allows one to get the customers phone number.
     *
     * @return Phone the customers phone number
     */
    public String getPhone() {
        return Phone;
    }

    /**
     * This method allows one to get the customers division id.
     *
     * @return Division_ID the customers Division_ID
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     * This method overrides the customer toString() method.
     *
     * @return String.valueOf(Customer_ID) the string equivalent of the customer id
     */
    public String toString() {
        return String.valueOf(customerID);
    }

}
