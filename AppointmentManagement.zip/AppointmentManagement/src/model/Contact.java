package model;

/**
 * This class allows one to create contact objects.
 */
public class Contact {
    private final int contactID;
    private final String contactName;
    private final String Email;

    /**
     * This is the constructor method for the Contact objects.
     *
     * @param contactID   the appointments contact id
     * @param contactName the appointments contact name
     * @param Email       the appointments email address
     */
    public Contact(int contactID, String contactName, String Email) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.Email = Email;

    }

    /**
     * This method allows one to get the contact id.
     *
     * @return Contact_ID the contact id
     */
    public int getContact_ID() {
        return contactID;
    }

    /**
     * This method allows one to get the contact name.
     *
     * @return Contact_Name the contact name
     */
    public String getContact_Name() {
        return contactName;
    }

    /**
     * This method allows one to get the email for a contact.
     *
     * @return Email the email for a contact
     */
    public String getEmail() {
        return Email;
    }

    /**
     * This method overrides to toString() method for contact objects.
     *
     * @return contactID the contact id
     * @return contactName the contact name
     */
    public String toString() {
        return contactID + "|" + contactName;
    }
}