package model;

/**
 * This class allows one to create Division objects.
 */
public class Division {

    private final int divisionID;
    private final String divisionName;
    private final int countryID;

    /**
     * This is a constructor method for Division objects.
     *
     * @param divisionID   the division id
     * @param divisionName the division name
     * @param countryID    the divisions country id
     */

    public Division(int divisionID, String divisionName, int countryID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.countryID = countryID;
    }

    /**
     * This method allows one to get the division id.
     *
     * @return Division_ID the Division id
     */
    public int getDivisionID() {
        return divisionID;
    }

    /**
     * This method allows one to get the division name.
     *
     * @return Division_Name the division name
     */
    public String getDivision() {
        return divisionName;
    }

    /**
     * This method allows one to get the divisions country id.
     *
     * @return Country_ID the divisions country id
     */
    public int getCountry_ID() {
        return countryID;
    }
    /**
     * This method overrides the toString() method for Division objects.
     *
     * @return getDivision() the divisions name
     */
    @Override
    public String toString() {
        return getDivision();
    }
}



